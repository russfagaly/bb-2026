"""
compile_sheets.py
=================
Pushes 2026 ALL MAJORS STATS to a live Google Sheet.

Usage
-----
    cd mnt/Stats
    python3 pipeline/compile_sheets.py

Creates the spreadsheet on first run inside the configured Drive folder.
On subsequent runs it finds the existing sheet by name and updates it in place —
your co-manager's link stays the same forever.

Requirements
------------
    pip install gspread google-auth --break-system-packages
    pipeline/credentials.json   ← service account key file
"""

import os, sys, re, importlib.util, time
from collections import defaultdict
from datetime import datetime

import gspread
from google.oauth2.service_account import Credentials

THIS_DIR   = os.path.dirname(os.path.abspath(__file__))
STATS_DIR  = os.path.dirname(THIS_DIR)
GAMES_DIR  = os.path.join(STATS_DIR, "games")
CREDS_FILE = os.path.join(THIS_DIR, "credentials.json")

# The live Google Sheet (created manually by Russ, shared with service account)
SHEET_ID   = "1wvF3cMIxd_XeI71QNM6gkyrK192QEc_uMm4hSUG67Ms"
SHEET_NAME = "2026 ALL MAJORS STATS"

# =============================================================================
# 1. CONNECT TO GOOGLE SHEETS
# =============================================================================
SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
]

def connect():
    creds = Credentials.from_service_account_file(CREDS_FILE, scopes=SCOPES)
    return gspread.authorize(creds)

# =============================================================================
# 2. LOAD ALL GAME FILES  (identical logic to compile.py)
# =============================================================================
all_hitting  = []
all_pitching = []

game_files = sorted(f for f in os.listdir(GAMES_DIR) if f.endswith('.py'))
if not game_files:
    sys.exit(f"No game files found in {GAMES_DIR}")

for fname in game_files:
    path = os.path.join(GAMES_DIR, fname)
    spec = importlib.util.spec_from_file_location("gf", path)
    mod  = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    team = mod.TEAM; date = mod.DATE
    for row in getattr(mod, 'hitting',  []): all_hitting.append({**row, 'team': team, 'date': date})
    for row in getattr(mod, 'pitching', []): all_pitching.append({**row, 'team': team, 'date': date})

print(f"Loaded {len(game_files)} game files: "
      f"{len(all_hitting)} hitting rows, {len(all_pitching)} pitching rows")

# ── Compute timestamps for the "last updated" indicator ──────────────────────
_all_dates = set(row['date'] for row in all_hitting) | set(row['date'] for row in all_pitching)
MOST_RECENT_GAME = max(_all_dates) if _all_dates else "N/A"
# Format: "March 25, 2026 at 11:45 AM"
COMPILED_AT = datetime.now().strftime("%-m/%-d/%Y at %-I:%M %p")
STAMP = f"Most recent game data: {MOST_RECENT_GAME}     ·     Last compiled: {COMPILED_AT}"

# =============================================================================
# 3. HELPERS
# =============================================================================
def display_name(raw):   return raw.split(' #')[0].strip()

def ip_to_dec(ip_str):
    s = str(ip_str)
    if '.' not in s: return float(s)
    w, f = s.split('.'); return int(w) + int(f) / 3.0

def dec_to_ip(dec):
    # Round to nearest out (1/3 inning) to avoid floating-point accumulation errors
    # e.g. three 1/3-inning stints sum to 0.9999... not 1.0, so int() would give wrong result
    t = round(dec * 3)
    return f"{t // 3}.{t % 3}"

def pct(n, d): return n/d if d else 0

# =============================================================================
# 4. AGGREGATION
# =============================================================================
h_totals = defaultdict(lambda: {'team':'','games':0,'ab':0,'r':0,'h':0,'rbi':0,
    'bb':0,'so':0,'sb':0,'cs':0,'e':0,'doubles':0,'triples':0,'hr':0,'hbp':0})
for row in all_hitting:
    key = (display_name(row['name']), row['team'])
    p = h_totals[key]; p['team'] = row['team']; p['games'] += 1
    for s in ('ab','r','h','rbi','bb','so','sb','cs','e','doubles','triples','hr','hbp'):
        p[s] += row.get(s, 0)

p_totals = defaultdict(lambda: {'team':'','games':0,'ip_dec':0.0,'h':0,'r':0,'er':0,
    'bb':0,'so':0,'pitches':0,'strikes':0,'bf':0,'hbp':0})
for row in all_pitching:
    key = (display_name(row['name']), row['team'])
    p = p_totals[key]; p['team'] = row['team']; p['games'] += 1
    p['ip_dec'] += ip_to_dec(row['ip'])
    for s in ('h','r','er','bb','so','hbp'): p[s] += row.get(s, 0)
    p['pitches'] += row.get('pitches', 0); p['strikes'] += row.get('strikes', 0)
    bf = row.get('bf', 0)
    if bf > 0: p['bf'] += bf

TEAMS = ['Astros','Brewers','Giants','Guardians','Marlins','Padres','White Sox','Yankees']
team_hit = {t: defaultdict(int) for t in TEAMS}
team_hit_dates = {t: set() for t in TEAMS}
for row in all_hitting:
    t = row['team']
    if t not in team_hit: continue
    team_hit_dates[t].add(row['date'])
    for s in ('ab','r','h','rbi','bb','so','sb','cs','e','doubles','triples','hr'):
        team_hit[t][s] += row.get(s, 0)

team_pit = {t: {'ip_dec':0.0,'h':0,'r':0,'er':0,'bb':0,'so':0,
                'pitches':0,'strikes':0,'bf':0,'hbp':0} for t in TEAMS}
team_pit_dates = {t: set() for t in TEAMS}
for row in all_pitching:
    t = row['team']
    if t not in team_pit: continue
    team_pit_dates[t].add(row['date'])
    team_pit[t]['ip_dec'] += ip_to_dec(row['ip'])
    for s in ('h','r','er','bb','so','hbp'): team_pit[t][s] += row.get(s, 0)
    team_pit[t]['pitches'] += row.get('pitches', 0)
    team_pit[t]['strikes'] += row.get('strikes', 0)
    bf = row.get('bf', 0)
    if bf > 0: team_pit[t]['bf'] += bf

hitting_players  = sorted([(d,p) for (d,_t),p in h_totals.items()],  key=lambda x:(x[1]['team'],x[0]))
pitching_players = sorted([(d,p) for (d,_t),p in p_totals.items()], key=lambda x:(x[1]['team'],x[0]))

qual_hitters  = [(n,p) for n,p in hitting_players  if p['ab'] >= 10]
all_hitters   = hitting_players
sb_hitters    = [(n,p) for n,p in hitting_players  if p['sb']+p['cs'] >= 1]
qual_pitchers = [(n,p) for n,p in pitching_players if p['ip_dec'] >= 6.0]
all_pitchers  = pitching_players
kbb_pitchers  = [(n,p) for n,p in pitching_players if p['bb'] > 0 and p['ip_dec'] >= 3.0]

# stat fns
def h_avg(p):      return pct(p['h'], p['ab'])
def h_obp(p):      return pct(p['h']+p['bb']+p['hbp'], p['ab']+p['bb']+p['hbp'])
def h_slg(p):      return pct(p['h']+p['doubles']+2*p['triples']+3*p['hr'], p['ab'])
def h_ops(p):      return h_obp(p) + h_slg(p)
def h_tb(p):       return p['h']+p['doubles']+2*p['triples']+3*p['hr']
def h_xbh(p):      return p['doubles']+p['triples']+p['hr']
def h_sb_pct(p):   return pct(p['sb'], p['sb']+p['cs'])
def h_walk_pct(p): return pct(p['bb'], p['ab']+p['bb'])
def h_so_pct(p):   return pct(p['so'], p['ab']+p['bb'])
def h_pa(p):       return p['ab'] + p['bb']
def h_avg(p):      return p['h'] / p['ab'] if p['ab'] >= 1 else 0
def h_slg(p):      return (p['h']+p['doubles']+2*p['triples']+3*p['hr']) / p['ab'] if p['ab'] >= 1 else 0
def h_iso(p):      return h_slg(p) - h_avg(p)
def h_babip(p):
    denom = p['ab'] - p['so'] - p['hr']
    return (p['h'] - p['hr']) / denom if denom >= 1 else 0
def p_era(p):      return p['er']*9/p['ip_dec']         if p['ip_dec']>0.01 else 99.0
def p_whip(p):     return (p['h']+p['bb'])/p['ip_dec']  if p['ip_dec']>0.01 else 99.0
def p_spct(p):     return pct(p['strikes'], p['pitches'])
def p_h6(p):       return 6*p['h']/p['ip_dec']          if p['ip_dec']>0 else 0
def p_bb6(p):      return 6*p['bb']/p['ip_dec']         if p['ip_dec']>0 else 0
def p_k6(p):       return 6*p['so']/p['ip_dec']         if p['ip_dec']>0 else 0
def p_wpct(p):     return pct(p['bb'], p['bf'])
def p_kpct(p):     return pct(p['so'], p['bf'])
def p_kbb(p):      return pct(p['so'], p['bb'])

# League averages for OPS+ and ERA+
_lg_h   = sum(p['h']   for _, p in hitting_players)
_lg_bb  = sum(p['bb']  for _, p in hitting_players)
_lg_hbp = sum(p['hbp'] for _, p in hitting_players)
_lg_ab  = sum(p['ab']  for _, p in hitting_players)
_lg_tb  = sum(p['h'] + p['doubles'] + 2*p['triples'] + 3*p['hr'] for _, p in hitting_players)
_lg_obp = (_lg_h + _lg_bb + _lg_hbp) / (_lg_ab + _lg_bb + _lg_hbp) if (_lg_ab + _lg_bb + _lg_hbp) > 0 else 1
_lg_slg = _lg_tb / _lg_ab                       if _lg_ab > 0           else 1
_lg_er     = sum(p['er']     for _, p in pitching_players)
_lg_ip     = sum(p['ip_dec'] for _, p in pitching_players)
_lg_era    = _lg_er * 9 / _lg_ip                if _lg_ip > 0           else 0
_lg_bb_pit = sum(p['bb']     for _, p in pitching_players)
_lg_so_pit = sum(p['so']     for _, p in pitching_players)
_fip_const = _lg_era - (3*_lg_bb_pit - 2*_lg_so_pit) / _lg_ip if _lg_ip > 0 else 0

def h_ops_plus(p):
    obp = (p['h']+p['bb']+p['hbp']) / (p['ab']+p['bb']+p['hbp']) if (p['ab']+p['bb']+p['hbp']) > 0 else 0
    slg = (p['h']+p['doubles']+2*p['triples']+3*p['hr']) / p['ab'] if p['ab'] > 0 else 0
    return round(100 * (obp / _lg_obp + slg / _lg_slg - 1)) if _lg_obp > 0 and _lg_slg > 0 else 100

def p_era_plus(p):
    if p['ip_dec'] <= 0.01: return 0
    era = p['er'] * 9 / p['ip_dec']
    if era == 0:  return 999
    return round(100 * _lg_era / era) if _lg_era > 0 else 0

def p_fip_minus(p):
    if p['ip_dec'] <= 0.01: return 0.0
    return round((3*p['bb'] - 2*p['so']) / p['ip_dec'] + _fip_const, 2)

def p_kbb_ratio(p):
    if p['bb'] == 0: return 99.0 if p['so'] > 0 else 0.0
    return round(p['so'] / p['bb'], 2)

# =============================================================================
# 5. GOOGLE SHEETS FORMATTING HELPERS
# =============================================================================
def rgb(hex_color):
    """'1F4E79' → {'red': 0.122, 'green': 0.306, 'blue': 0.475}"""
    h = hex_color.lstrip('#')
    return {'red': int(h[0:2],16)/255, 'green': int(h[2:4],16)/255, 'blue': int(h[4:6],16)/255}

def cell_fmt(bg=None, bold=False, italic=False, color='000000', size=10,
             halign='CENTER', valign='MIDDLE', fmt_pattern=None):
    f = {
        'textFormat': {
            'bold': bold, 'italic': italic,
            'foregroundColor': rgb(color),
            'fontSize': size,
            'fontFamily': 'Arial',
        },
        'horizontalAlignment': halign,
        'verticalAlignment': valign,
    }
    if bg:
        f['backgroundColor'] = rgb(bg)
    if fmt_pattern:
        f['numberFormat'] = {'type': 'NUMBER', 'pattern': fmt_pattern}
    return f

def range_fmt_req(sheet_id, r1, c1, r2, c2, fmt):
    """Build a repeatCell request for the Sheets batchUpdate API."""
    fields = 'userEnteredFormat(' + ','.join([
        'backgroundColor','textFormat','horizontalAlignment',
        'verticalAlignment','numberFormat'
    ]) + ')'
    return {
        'repeatCell': {
            'range': {
                'sheetId': sheet_id,
                'startRowIndex': r1, 'endRowIndex': r2,
                'startColumnIndex': c1, 'endColumnIndex': c2,
            },
            'cell': {'userEnteredFormat': fmt},
            'fields': fields,
        }
    }

def merge_req(sheet_id, r1, c1, r2, c2):
    return {
        'mergeCells': {
            'range': {
                'sheetId': sheet_id,
                'startRowIndex': r1, 'endRowIndex': r2,
                'startColumnIndex': c1, 'endColumnIndex': c2,
            },
            'mergeType': 'MERGE_ALL',
        }
    }

def col_width_req(sheet_id, col_idx, px):
    return {
        'updateDimensionProperties': {
            'range': {
                'sheetId': sheet_id,
                'dimension': 'COLUMNS',
                'startIndex': col_idx,
                'endIndex': col_idx + 1,
            },
            'properties': {'pixelSize': px},
            'fields': 'pixelSize',
        }
    }

def row_height_req(sheet_id, row_idx, px):
    return {
        'updateDimensionProperties': {
            'range': {
                'sheetId': sheet_id,
                'dimension': 'ROWS',
                'startIndex': row_idx,
                'endIndex': row_idx + 1,
            },
            'properties': {'pixelSize': px},
            'fields': 'pixelSize',
        }
    }

def freeze_req(sheet_id, rows=0, cols=0):
    return {
        'updateSheetProperties': {
            'properties': {
                'sheetId': sheet_id,
                'gridProperties': {'frozenRowCount': rows, 'frozenColumnCount': cols},
            },
            'fields': 'gridProperties.frozenRowCount,gridProperties.frozenColumnCount',
        }
    }

def basic_filter_req(sheet_id, num_cols):
    # No endRowIndex = filter extends to end of sheet, enabling sort across all data rows
    return {
        'setBasicFilter': {
            'filter': {
                'range': {
                    'sheetId': sheet_id,
                    'startRowIndex': 2,   # 0-based: row 3 (header row)
                    'startColumnIndex': 0,
                    'endColumnIndex': num_cols,
                }
            }
        }
    }

def tab_color_req(sheet_id, hex_color):
    return {
        'updateSheetProperties': {
            'properties': {
                'sheetId': sheet_id,
                'tabColorStyle': {'rgbColor': rgb(hex_color)},
            },
            'fields': 'tabColorStyle',
        }
    }

# =============================================================================
# 6. LEADERBOARD GRID BUILDER
#    Returns (grid_data, format_requests, merge_requests) for one leaderboard sheet
# =============================================================================
TOP_N        = 12
BLOCK_HEIGHT = TOP_N + 2   # title + header + 12 rows = 14
ROW_GAP      = 2
BLOCK_COLS_0 = [0, 5, 10, 15, 20, 25]  # 0-indexed col starts

def build_lb_grid(categories, sheet_id, start_row_0, subhdr_hex, row1_hex):
    """
    Build an N-row × 6-col leaderboard grid (N determined by len(categories)).
    Returns (data_2d, fmt_reqs, merge_reqs).
    data_2d is a list of rows (each row = list of cell values, '' for empty).
    start_row_0: 0-indexed row where the grid starts (after the title rows).
    """
    import math
    n_grid_rows = math.ceil(len(categories) / 6)
    # Calculate total rows needed
    total_rows = n_grid_rows * BLOCK_HEIGHT + (n_grid_rows - 1) * ROW_GAP
    total_cols = 29   # cols 0-28

    data = [['' for _ in range(total_cols)] for _ in range(total_rows)]
    fmt_reqs  = []
    merge_reqs = []

    for grid_row in range(n_grid_rows):
        r0 = grid_row * (BLOCK_HEIGHT + ROW_GAP)   # relative to grid start
        abs_r0 = start_row_0 + r0                  # absolute 0-indexed row

        for grid_col in range(6):
            cat_idx = grid_row * 6 + grid_col
            if cat_idx >= len(categories): break
            cat    = categories[cat_idx]
            title, pool, sort_fn, fmt_pat, higher_better = cat[:5]
            disp_fn = cat[5] if len(cat) > 5 else None
            c0 = BLOCK_COLS_0[grid_col]

            # Title row (merged across 4 cols)
            data[r0][c0] = title
            merge_reqs.append(merge_req(sheet_id, abs_r0, c0, abs_r0+1, c0+4))
            fmt_reqs.append(range_fmt_req(sheet_id, abs_r0, c0, abs_r0+1, c0+4,
                cell_fmt(bg=subhdr_hex, bold=True, color='FFFFFF', size=9)))

            # Header row
            for i, h in enumerate(['Rk','Player','Team','Stat']):
                data[r0+1][c0+i] = h
            fmt_reqs.append(range_fmt_req(sheet_id, abs_r0+1, c0, abs_r0+2, c0+4,
                cell_fmt(bg=subhdr_hex, bold=True, color='FFFFFF', size=9)))

            # Data rows
            sorted_pool = sorted(pool, key=lambda x: sort_fn(x[1]),
                                  reverse=higher_better)[:TOP_N]
            for rank, (name, p) in enumerate(sorted_pool, 1):
                dr   = r0 + 1 + rank
                abs_dr = abs_r0 + 1 + rank
                raw  = sort_fn(p)
                disp = disp_fn(raw) if disp_fn else raw
                bg   = row1_hex if rank % 2 == 1 else 'FFFFFF'

                # Format stat cell value
                if fmt_pat and disp_fn is None:
                    if '%' in fmt_pat:
                        stat_val = f"{raw:.1%}"
                    elif '000' in fmt_pat:
                        stat_val = f"{raw:.3f}"
                    elif '00' in fmt_pat:
                        stat_val = f"{raw:.2f}"
                    else:
                        stat_val = raw
                else:
                    stat_val = disp

                data[dr][c0]   = rank
                data[dr][c0+1] = name
                data[dr][c0+2] = p['team']
                data[dr][c0+3] = stat_val

                fmt_reqs.append(range_fmt_req(sheet_id, abs_dr, c0, abs_dr+1, c0+4,
                    cell_fmt(bg=bg, size=9)))
                # Player name left-aligned
                fmt_reqs.append(range_fmt_req(sheet_id, abs_dr, c0+1, abs_dr+1, c0+2,
                    cell_fmt(bg=bg, size=9, halign='LEFT')))

    return data, fmt_reqs, merge_reqs


# =============================================================================
# 7. GET OR CREATE SPREADSHEET
# =============================================================================
def get_or_create_spreadsheet(gc):
    """Open the spreadsheet by its fixed ID."""
    print(f"Opening sheet {SHEET_ID}...")
    sh = gc.open_by_key(SHEET_ID)
    print(f"Opened: {sh.title}")
    return sh


# =============================================================================
# 8. BUILD EACH TAB
# =============================================================================
TAB_DEFS = [
    {"title": "🏆 Hitting Leaders",      "tab_color": "2E75B6"},
    {"title": "⚾ Pitching Leaders",     "tab_color": "375623"},
    {"title": "📊 Team Hitting",         "tab_color": "595959"},
    {"title": "📊 Team Pitching",        "tab_color": "595959"},
    {"title": "🥎 Player Hitting",       "tab_color": "2E75B6"},
    {"title": "🎯 Player Pitching",      "tab_color": "375623"},
    {"title": "⭐ All Star Tracker",     "tab_color": "B8860B"},
    {"title": "📋 Standings & Results",  "tab_color": "1A6B6B"},
]

# Roster definitions for All Star Tracker tab.
# Each entry: (short_lookup, full_display_name, team)
# short_lookup must match display_name() output from game files.
# Use None for players confirmed not in the Majors database.
# rank_age = the current 2026 baseball age of players in this group.
# Rankings compare each player against all Majors players of the same age.
#   2025 11u All Stars    → now age 12
#   2025 10u All Stars    → now age 11
#   2025 11u Future Stars → now age 12
TRACKER_ROSTERS = [
    ("2025 11u All Stars", 12, [
        ("Jonah L",   "Jonah Lee",           "Giants"),
        ("Kaleo P",   "Kaleo Pontemayor",    "Marlins"),
        ("Huston G",  "Huston Garvine",      "Brewers"),
        ("Colton D",  "Colton Dignon",       "Astros"),
        ("Adrien R",  "Adrien Romero",       "White Sox"),
        ("Orion M",   "Orion Mitchell",      "Padres"),
        ("RJ F",      "RJ Fagaly",           "Padres"),
        ("Kai L",     "Kai Lin",             "Giants"),
        ("Jordan C",  "Jordan Cerda-Zein",   "Astros"),
        ("Drew B",    "Drew Bryant",         "Guardians"),
        ("Nico Y",    "Nico Yuen",           "Marlins"),
        ("Roland M",  "Roland Hatley",       "Yankees"),
        ("Hudson P",  "Hudson Patterson",    "Yankees"),
    ]),
    ("2025 10u All Stars", 11, [
        ("Jax H",     "Jax Huang",           "Marlins"),
        ("Max M",     "Max Moffett",         "Yankees"),
        ("Julian P",  "Julian Paiso",        "Astros"),
        ("Aiden G",   "Aiden Gilling",       "Giants"),
        ("Ace B",     "Ace Beaver",          "White Sox"),
        ("Connor Z",  "Connor Zuckerman",    "Astros"),
        ("Cameron L", "Cameron Le",          "Giants"),
        ("Jaxon M",   "Jaxon Mooningham",    "Giants"),
        ("Conor F",   "Conor Fogarty",       "Guardians"),
        ("Wilder E",  "Wilder Eula",         "Marlins"),
        ("Luciano A", "Luciano Arce",        "Brewers"),
        ("King N",    "King Nguyen",         "Brewers"),
        ("Adrian T",  "AJ Thomas",           "Padres"),
    ]),
    ("2025 11u Future Stars", 12, [
        ("Miles D",   "Miles Denman",        "Padres"),
        ("Lennon D",  "Lennon Danielsson",   "Guardians"),
        ("Julius N",  "Julius Norgren",      "White Sox"),
        ("Zach C",    "Zach Cheng",          "Brewers"),
        ("Mayer H",   "Mayer Hemberg",       "Marlins"),
        ("Samuel G",  "Sam Gilmore",         "Padres"),
        ("Miles M",   "Miles Moyer",         "Brewers"),
        ("Carter F",  "Carter Flores",       "Astros"),
        ("Soren K",   "Soren Krajewski",     "Guardians"),
        ("Julian W",  "Julian Warner",       "Marlins"),
        ("Carver D",  "Carver Dole",         "Giants"),
        ("Sam E",     "Sammy Engel",         "White Sox"),
        ("Benny M",   "Benny McDaniels",     "Yankees"),
    ]),
]

def setup_worksheets(sh):
    """Ensure all 6 tabs exist in the right order, clearing old data."""
    existing = {ws.title: ws for ws in sh.worksheets()}

    # Add missing tabs
    for td in TAB_DEFS:
        if td["title"] not in existing:
            sh.add_worksheet(title=td["title"], rows=200, cols=30)

    # Remove any sheet not in our list (e.g., default "Sheet1")
    wanted = {td["title"] for td in TAB_DEFS}
    for ws in sh.worksheets():
        if ws.title not in wanted:
            sh.del_worksheet(ws)

    # Reorder tabs to match TAB_DEFS order
    sh.reorder_worksheets([sh.worksheet(td["title"]) for td in TAB_DEFS])

    # Return dict of title → worksheet
    return {ws.title: ws for ws in sh.worksheets()}


def push_hitting_leaders(sh, ws):
    sid = ws.id
    HIT_CATS = [
        ("Batting Avg (AVG)",  qual_hitters, h_avg,                 '0.000', True),
        ("On-Base Pct (OBP)",  qual_hitters, h_obp,                 '0.000', True),
        ("Slugging Pct (SLG)", qual_hitters, h_slg,                 '0.000', True),
        ("OPS",                qual_hitters, h_ops,                 '0.000', True),
        ("Hits (H)",           all_hitters,  lambda p: p['h'],       None,   True),
        ("RBI",                all_hitters,  lambda p: p['rbi'],     None,   True),
        ("Runs Scored (R)",    all_hitters,  lambda p: p['r'],       None,   True),
        ("Total Bases (TB)",   all_hitters,  h_tb,                   None,   True),
        ("Walks (BB)",         all_hitters,  lambda p: p['bb'],      None,   True),
        ("Doubles (2B)",       all_hitters,  lambda p: p['doubles'], None,   True),
        ("Triples (3B)",       all_hitters,  lambda p: p['triples'], None,   True),
        ("Home Runs (HR)",     all_hitters,  lambda p: p['hr'],      None,   True),
        ("Stolen Bases (SB)",  all_hitters,  lambda p: p['sb'],      None,   True),
        ("SB% (min 1 att)",    sb_hitters,   h_sb_pct,               '0.0%', True),
        ("Walk % (min 10 AB)", qual_hitters, h_walk_pct,             '0.0%', True),
        ("K% Fewest (min 10)", qual_hitters, h_so_pct,               '0.0%', False),
        ("Extra Base Hits",    all_hitters,  h_xbh,                  None,   True),
        ("Errors (Most)",      all_hitters,  lambda p: p['e'],       None,   True),
        # Row 4
        ("Ks (Most)",          all_hitters,  lambda p: p['so'],      None,   True),
        ("K% Most (min 10 AB)",qual_hitters, h_so_pct,               '0.0%', True),
        ("Plate Appearances",  all_hitters,  h_pa,                   None,   True),
        ("ISO (min 10 AB)",    qual_hitters, h_iso,                  '0.000',True),
        ("BABIP (min 10 AB)",  qual_hitters, h_babip,                '0.000',True),
        ("RBI / PA",           qual_hitters, lambda p: p['rbi'] / h_pa(p) if h_pa(p) > 0 else 0, '0.000', True),
    ]

    # Title rows
    title_row  = ["2026 Alameda Little League Majors — HITTING LEADERBOARD"] + ['']*28
    subttl_row = [f"Min 10 AB for rate stats.  Min 1 SB attempt for SB%.     {STAMP}"] + ['']*28

    grid_data, fmt_reqs, merge_reqs = build_lb_grid(HIT_CATS, sid, 2, '2E75B6', 'D6E4F0')

    all_data = [title_row, subttl_row] + grid_data
    ws.clear()
    # Unmerge + reset all backgrounds before writing — stale merges/colors persist after clear()
    sh.batch_update({'requests': [
        {'unmergeCells': {'range': {
            'sheetId': sid,
            'startRowIndex': 0, 'endRowIndex': 80,
            'startColumnIndex': 0, 'endColumnIndex': 29,
        }}},
        {'repeatCell': {
            'range': {
                'sheetId': sid,
                'startRowIndex': 0, 'endRowIndex': 80,
                'startColumnIndex': 0, 'endColumnIndex': 29,
            },
            'cell': {'userEnteredFormat': {
                'backgroundColor': {'red': 1.0, 'green': 1.0, 'blue': 1.0},
            }},
            'fields': 'userEnteredFormat.backgroundColor',
        }},
    ]})
    ws.update(all_data, 'A1', value_input_option='USER_ENTERED')

    reqs = []
    # Title formatting
    reqs.append(merge_req(sid, 0, 0, 1, 29))
    reqs.append(range_fmt_req(sid, 0, 0, 1, 29,
        cell_fmt(bg='1F4E79', bold=True, color='FFFFFF', size=16)))
    reqs.append(merge_req(sid, 1, 0, 2, 29))
    reqs.append(range_fmt_req(sid, 1, 0, 2, 29,
        cell_fmt(bg='2E75B6', italic=True, color='FFFFFF', size=9)))
    reqs.extend(merge_reqs)
    reqs.extend(fmt_reqs)
    reqs.append(freeze_req(sid, rows=3))
    reqs.append(tab_color_req(sid, '2E75B6'))
    # Column widths: Rk=40, Player=130, Team=90, Stat=70, gap=18
    for bc in BLOCK_COLS_0:
        reqs += [col_width_req(sid, bc, 40), col_width_req(sid, bc+1, 130),
                 col_width_req(sid, bc+2, 90), col_width_req(sid, bc+3, 70)]
        if bc < BLOCK_COLS_0[-1]:
            reqs.append(col_width_req(sid, bc+4, 18))

    sh.batch_update({'requests': reqs})


def push_pitching_leaders(sh, ws):
    sid = ws.id
    PIT_CATS = [
        ("Innings Pitched",        all_pitchers,  lambda p: p['ip_dec'],  None,   True, dec_to_ip),
        ("ERA (min 6 IP)",         qual_pitchers, p_era,                  '0.00', False),
        ("Hits Allowed (Fewest, min 6 IP)",  qual_pitchers,  lambda p: p['h'],       None,   False),
        ("Runs Allowed (Most)",    all_pitchers,  lambda p: p['r'],       None,   True),
        ("Earned Runs (Most)",     all_pitchers,  lambda p: p['er'],      None,   True),
        ("Walks",                  all_pitchers,  lambda p: p['bb'],      None,   True),
        ("Strikeouts (SO)",        all_pitchers,  lambda p: p['so'],      None,   True),
        ("Pitches Thrown",         all_pitchers,  lambda p: p['pitches'], None,   True),
        ("Strike % (min 6 IP)",    qual_pitchers, p_spct,                 '0.0%', True),
        ("HBP Most",               all_pitchers,  lambda p: p['hbp'],     None,   True),
        ("WHIP (min 6 IP)",        qual_pitchers, p_whip,                 '0.00', False),
        ("H per 6 IP (min 6 IP)",  qual_pitchers, p_h6,                   '0.00', False),
        ("BB per 6 IP (min 6 IP)", qual_pitchers, p_bb6,                  '0.00', False),
        ("K per 6 IP (min 6 IP)",  qual_pitchers, p_k6,                   '0.00', True),
        ("Walk % (min 6 IP)",      qual_pitchers, p_wpct,                 '0.0%', False),
        ("K% (min 6 IP)",          qual_pitchers, p_kpct,                 '0.0%', True),
        ("Batters Faced (BF)",     all_pitchers,  lambda p: p['bf'],      None,   True),
        ("K/BB Ratio (min 6 IP)",  kbb_pitchers,  p_kbb,                  '0.00', True),
    ]

    title_row  = ["2026 Alameda Little League Majors — PITCHING LEADERBOARD"] + ['']*28
    subttl_row = [f"Min 6 IP for rate stats.  Min 1 BB for K/BB ratio.     {STAMP}"] + ['']*28

    grid_data, fmt_reqs, merge_reqs = build_lb_grid(PIT_CATS, sid, 2, '375623', 'D9EAD3')

    all_data = [title_row, subttl_row] + grid_data
    ws.clear()
    # Unmerge + reset all backgrounds before writing — stale merges/colors persist after clear()
    sh.batch_update({'requests': [
        {'unmergeCells': {'range': {
            'sheetId': sid,
            'startRowIndex': 0, 'endRowIndex': 80,
            'startColumnIndex': 0, 'endColumnIndex': 29,
        }}},
        {'repeatCell': {
            'range': {
                'sheetId': sid,
                'startRowIndex': 0, 'endRowIndex': 80,
                'startColumnIndex': 0, 'endColumnIndex': 29,
            },
            'cell': {'userEnteredFormat': {
                'backgroundColor': {'red': 1.0, 'green': 1.0, 'blue': 1.0},
            }},
            'fields': 'userEnteredFormat.backgroundColor',
        }},
    ]})
    ws.update(all_data, 'A1', value_input_option='USER_ENTERED')

    reqs = []
    reqs.append(merge_req(sid, 0, 0, 1, 29))
    reqs.append(range_fmt_req(sid, 0, 0, 1, 29,
        cell_fmt(bg='1E4620', bold=True, color='FFFFFF', size=16)))
    reqs.append(merge_req(sid, 1, 0, 2, 29))
    reqs.append(range_fmt_req(sid, 1, 0, 2, 29,
        cell_fmt(bg='375623', italic=True, color='FFFFFF', size=9)))
    reqs.extend(merge_reqs)
    reqs.extend(fmt_reqs)
    reqs.append(freeze_req(sid, rows=3))
    reqs.append(tab_color_req(sid, '375623'))
    for bc in BLOCK_COLS_0:
        reqs += [col_width_req(sid, bc, 40), col_width_req(sid, bc+1, 130),
                 col_width_req(sid, bc+2, 90), col_width_req(sid, bc+3, 70)]
        if bc < BLOCK_COLS_0[-1]:
            reqs.append(col_width_req(sid, bc+4, 18))

    sh.batch_update({'requests': reqs})


def push_team_hitting(sh, ws):
    sid = ws.id
    headers = ['Team','G','AB','R','H','2B','3B','HR','RBI','BB','SO','SB','CS','E','AVG','OBP','SLG']
    rows = [["2026 Alameda Little League Majors — TEAM HITTING STATISTICS"] + ['']*16,
            [STAMP] + ['']*16,
            headers]

    for team in TEAMS:
        th = team_hit[team]; g = len(team_hit_dates[team])
        ab=th['ab']; h_=th['h']; bb=th['bb']; d=th['doubles']; t_=th['triples']; hr=th['hr']
        avg = f"{h_/ab:.3f}" if ab>0 else ".000"
        obp = f"{(h_+bb)/(ab+bb):.3f}" if (ab+bb)>0 else ".000"
        slg = f"{(h_+d+2*t_+3*hr)/ab:.3f}" if ab>0 else ".000"
        rows.append([team,g,ab,th['r'],h_,d,t_,hr,th['rbi'],bb,th['so'],
                     th['sb'],th['cs'],th['e'],avg,obp,slg])

    ws.clear()
    ws.update(rows, 'A1', value_input_option='USER_ENTERED')

    reqs = []
    reqs.append(merge_req(sid, 0, 0, 1, 17))
    reqs.append(range_fmt_req(sid, 0, 0, 1, 17, cell_fmt(bg='404040', bold=True, color='FFFFFF', size=14)))
    reqs.append(merge_req(sid, 1, 0, 2, 17))
    reqs.append(range_fmt_req(sid, 1, 0, 2, 17, cell_fmt(bg='595959', italic=True, color='FFFFFF', size=9)))
    reqs.append(range_fmt_req(sid, 2, 0, 3, 17, cell_fmt(bg='595959', bold=True, color='FFFFFF', size=10)))
    for i, team in enumerate(TEAMS):
        bg = 'F2F2F2' if i%2==0 else 'FFFFFF'
        abs_r = 3 + i
        reqs.append(range_fmt_req(sid, abs_r, 0, abs_r+1, 17, cell_fmt(bg=bg, size=10)))
        reqs.append(range_fmt_req(sid, abs_r, 0, abs_r+1, 1,  cell_fmt(bg=bg, size=10, halign='LEFT')))
    reqs.append(basic_filter_req(sid, 17))
    reqs.append(freeze_req(sid, rows=3))
    reqs.append(tab_color_req(sid, '595959'))
    widths = [120,40,55,50,50,50,50,50,50,50,50,50,50,50,65,65,65]
    for i, w in enumerate(widths): reqs.append(col_width_req(sid, i, w))
    sh.batch_update({'requests': reqs})


def push_team_pitching(sh, ws):
    sid = ws.id
    headers = ['Team','G','IP','H','R','ER','BB','SO','HBP','BF','ERA','WHIP','K/IP','Pitches','Strikes','Strike%']
    rows = [["2026 Alameda Little League Majors — TEAM PITCHING STATISTICS"] + ['']*15,
            [STAMP] + ['']*15,
            headers]

    for team in TEAMS:
        tp = team_pit[team]; g = len(team_pit_dates[team]); ip_d = tp['ip_dec']
        era    = f"{tp['er']*9/ip_d:.2f}"       if ip_d>0          else "0.00"
        whip   = f"{(tp['h']+tp['bb'])/ip_d:.2f}" if ip_d>0        else "0.00"
        kip    = f"{tp['so']/ip_d:.2f}"          if ip_d>0          else "0.00"
        spct   = f"{tp['strikes']/tp['pitches']:.1%}" if tp['pitches']>0 else "0.0%"
        rows.append([team, g, dec_to_ip(ip_d), tp['h'], tp['r'], tp['er'],
                     tp['bb'], tp['so'], tp['hbp'], tp['bf'],
                     era, whip, kip, tp['pitches'], tp['strikes'], spct])

    ws.clear()
    ws.update(rows, 'A1', value_input_option='USER_ENTERED')

    reqs = []
    reqs.append(merge_req(sid, 0, 0, 1, 16))
    reqs.append(range_fmt_req(sid, 0, 0, 1, 16, cell_fmt(bg='404040', bold=True, color='FFFFFF', size=14)))
    reqs.append(merge_req(sid, 1, 0, 2, 16))
    reqs.append(range_fmt_req(sid, 1, 0, 2, 16, cell_fmt(bg='595959', italic=True, color='FFFFFF', size=9)))
    reqs.append(range_fmt_req(sid, 2, 0, 3, 16, cell_fmt(bg='595959', bold=True, color='FFFFFF', size=10)))
    for i, team in enumerate(TEAMS):
        bg = 'F2F2F2' if i%2==0 else 'FFFFFF'
        abs_r = 3 + i
        reqs.append(range_fmt_req(sid, abs_r, 0, abs_r+1, 16, cell_fmt(bg=bg, size=10)))
        reqs.append(range_fmt_req(sid, abs_r, 0, abs_r+1, 1,  cell_fmt(bg=bg, size=10, halign='LEFT')))
    reqs.append(basic_filter_req(sid, 16))
    reqs.append(freeze_req(sid, rows=3))
    reqs.append(tab_color_req(sid, '595959'))
    widths = [120,40,55,50,50,50,50,50,50,50,65,65,65,70,70,70]
    for i, w in enumerate(widths): reqs.append(col_width_req(sid, i, w))
    sh.batch_update({'requests': reqs})


def push_player_hitting(sh, ws):
    sid = ws.id
    headers = ['Player','Team','GP','AB','R','H','2B','3B','HR','RBI',
               'BB','SO','SB','CS','E','AVG','OBP','SLG','OPS','OPS+']
    rows = [["2026 Alameda Little League Majors — PLAYER HITTING STATISTICS"] + ['']*19,
            [STAMP] + ['']*19,
            headers]

    for name, p in hitting_players:
        ab=p['ab']; h_=p['h']; bb=p['bb']; d=p['doubles']; t_=p['triples']; hr=p['hr']
        avg = f"{h_/ab:.3f}"               if ab>0        else ".000"
        obp = f"{(h_+bb)/(ab+bb):.3f}"     if (ab+bb)>0   else ".000"
        slg = f"{(h_+d+2*t_+3*hr)/ab:.3f}" if ab>0        else ".000"
        ops_v = (h_+bb)/(ab+bb) + (h_+d+2*t_+3*hr)/ab if (ab>0 and (ab+bb)>0) else 0
        ops = f"{ops_v:.3f}"
        ops_plus = h_ops_plus(p)
        rows.append([name, p['team'], p['games'], ab, p['r'], h_,
                     d, t_, hr, p['rbi'], bb, p['so'],
                     p['sb'], p['cs'], p['e'], avg, obp, slg, ops, ops_plus])

    ws.clear()
    ws.update(rows, 'A1', value_input_option='USER_ENTERED')

    reqs = []
    reqs.append(merge_req(sid, 0, 0, 1, 20))
    reqs.append(range_fmt_req(sid, 0, 0, 1, 20, cell_fmt(bg='1F4E79', bold=True, color='FFFFFF', size=14)))
    reqs.append(merge_req(sid, 1, 0, 2, 20))
    reqs.append(range_fmt_req(sid, 1, 0, 2, 20, cell_fmt(bg='2E75B6', italic=True, color='FFFFFF', size=9)))
    reqs.append(range_fmt_req(sid, 2, 0, 3, 20, cell_fmt(bg='2E75B6', bold=True, color='FFFFFF', size=10)))
    for i in range(len(hitting_players)):
        bg = 'D6E4F0' if i%2==0 else 'FFFFFF'
        abs_r = 3 + i
        reqs.append(range_fmt_req(sid, abs_r, 0, abs_r+1, 20, cell_fmt(bg=bg, size=10)))
        reqs.append(range_fmt_req(sid, abs_r, 0, abs_r+1, 2,  cell_fmt(bg=bg, size=10, halign='LEFT')))
    reqs.append(basic_filter_req(sid, 20))
    reqs.append(freeze_req(sid, rows=3))
    reqs.append(tab_color_req(sid, '2E75B6'))
    widths = [150,100,40,45,45,45,45,45,45,45,45,45,45,45,45,65,65,65,65,55]
    for i, w in enumerate(widths): reqs.append(col_width_req(sid, i, w))
    sh.batch_update({'requests': reqs})


def push_player_pitching(sh, ws):
    sid = ws.id
    headers = ['Player','Team','G','IP','H','R','ER','BB','SO','HBP',
               'Pitches','Strikes','Strike%','BF','ERA','WHIP','K/IP','K/BB','FIP-','ERA+']
    rows = [["2026 Alameda Little League Majors — PLAYER PITCHING STATISTICS"] + ['']*19,
            [STAMP] + ['']*19,
            headers]

    for name, p in pitching_players:
        ip_d = p['ip_dec']
        spct      = f"{p['strikes']/p['pitches']:.1%}" if p['pitches']>0 else "0.0%"
        era       = f"{p['er']*9/ip_d:.2f}"            if ip_d>0         else "0.00"
        whip      = f"{(p['h']+p['bb'])/ip_d:.2f}"     if ip_d>0         else "0.00"
        kip       = f"{p['so']/ip_d:.2f}"              if ip_d>0         else "0.00"
        era_plus  = p_era_plus(p)
        fip_minus = p_fip_minus(p)
        kbb       = p_kbb_ratio(p)
        rows.append([name, p['team'], p['games'], dec_to_ip(ip_d),
                     p['h'], p['r'], p['er'], p['bb'], p['so'], p['hbp'],
                     p['pitches'], p['strikes'], spct, p['bf'], era, whip, kip,
                     kbb, fip_minus, era_plus])

    ws.clear()
    ws.update(rows, 'A1', value_input_option='USER_ENTERED')

    reqs = []
    reqs.append(merge_req(sid, 0, 0, 1, 20))
    reqs.append(range_fmt_req(sid, 0, 0, 1, 20, cell_fmt(bg='1E4620', bold=True, color='FFFFFF', size=14)))
    reqs.append(merge_req(sid, 1, 0, 2, 20))
    reqs.append(range_fmt_req(sid, 1, 0, 2, 20, cell_fmt(bg='375623', italic=True, color='FFFFFF', size=9)))
    reqs.append(range_fmt_req(sid, 2, 0, 3, 20, cell_fmt(bg='375623', bold=True, color='FFFFFF', size=10)))
    for i in range(len(pitching_players)):
        bg = 'D9EAD3' if i%2==0 else 'FFFFFF'
        abs_r = 3 + i
        reqs.append(range_fmt_req(sid, abs_r, 0, abs_r+1, 20, cell_fmt(bg=bg, size=10)))
        reqs.append(range_fmt_req(sid, abs_r, 0, abs_r+1, 2,  cell_fmt(bg=bg, size=10, halign='LEFT')))
    reqs.append(basic_filter_req(sid, 20))
    reqs.append(freeze_req(sid, rows=3))
    reqs.append(tab_color_req(sid, '375623'))
    widths = [150,100,40,55,45,45,45,45,45,45,70,70,70,45,65,65,65,55,65,65]
    for i, w in enumerate(widths): reqs.append(col_width_req(sid, i, w))
    sh.batch_update({'requests': reqs})


def push_all_star_tracker(sh, ws):
    sid = ws.id
    reqs = []
    rows = []
    cur_r = 0   # 0-indexed running row pointer

    N_COLS = 22  # Player, Team, AVG, Rk, H, Rk, HR, Rk, RBI, Rk, R, Rk, SB, Rk, BB, Rk, IP, Rk, ERA, Rk, Strike%, Rk

    def _rank_dict(totals, val_fn, higher_better=True):
        valued = [(k, val_fn(p)) for k, p in totals.items() if val_fn(p) is not None]
        valued.sort(key=lambda x: x[1], reverse=higher_better)
        ranks = {}; prev_v = None; prev_r = 0
        for j, (k, v) in enumerate(valued, 1):
            ranks[k] = prev_r if v == prev_v else j
            if v != prev_v: prev_r = j; prev_v = v
        return ranks

    # Rank dicts are built per age group so each player is ranked only
    # against peers of the same current baseball age.
    AST_MIN_IP = 6.0
    from roster import get_age as _ast_get_age

    def _make_ast_ranks(rank_age):
        ht = {k: v for k, v in h_totals.items() if _ast_get_age(k[0], k[1]) == rank_age}
        pt = {k: v for k, v in p_totals.items() if _ast_get_age(k[0], k[1]) == rank_age}
        return {
            'avg': _rank_dict(ht, lambda p: p['h']/p['ab'] if p['ab']>0 else None, True),
            'h':   _rank_dict(ht, lambda p: p['h']   if p['ab']>0 else None, True),
            'hr':  _rank_dict(ht, lambda p: p['hr']  if p['ab']>0 else None, True),
            'rbi': _rank_dict(ht, lambda p: p['rbi'] if p['ab']>0 else None, True),
            'r':   _rank_dict(ht, lambda p: p['r']   if p['ab']>0 else None, True),
            'sb':  _rank_dict(ht, lambda p: p['sb']  if p['ab']>0 else None, True),
            'bb':  _rank_dict(ht, lambda p: p['bb']  if p['ab']>0 else None, True),
            'ip':  _rank_dict(pt, lambda p: p['ip_dec'] if p['ip_dec']>=AST_MIN_IP else None, True),
            'era': _rank_dict(pt, lambda p: p['er']*9/p['ip_dec'] if p['ip_dec']>=AST_MIN_IP else None, False),
            'str': _rank_dict(pt, lambda p: p['strikes']/p['pitches'] if (p['pitches']>0 and p['ip_dec']>=AST_MIN_IP) else None, True),
        }

    _rk_cache = {}

    # Sheet-level header + qualifier note
    rows.append(["⭐ All Star Tracker — 2026 Alameda Little League Majors"] + [''] * (N_COLS - 1))
    reqs.append(merge_req(sid, cur_r, 0, cur_r + 1, N_COLS))
    reqs.append(range_fmt_req(sid, cur_r, 0, cur_r + 1, N_COLS,
        cell_fmt(bg='7B5E00', bold=True, color='FFFFFF', size=13)))
    cur_r += 1

    rows.append(["Sorted by AVG.  Rankings compare each player against their age-group peers (age 12 for former 11u groups, age 11 for former 10u group).  Pitching rankings require min. 6.0 IP."] + [''] * (N_COLS - 1))
    reqs.append(merge_req(sid, cur_r, 0, cur_r + 1, N_COLS))
    reqs.append(range_fmt_req(sid, cur_r, 0, cur_r + 1, N_COLS,
        cell_fmt(bg='C9A227', italic=True, color='FFFFFF', size=9)))
    cur_r += 1

    rows.append([''] * N_COLS)  # blank row before first group
    cur_r += 1

    for roster_title, rank_age, players in TRACKER_ROSTERS:
        rk = _rk_cache.setdefault(rank_age, _make_ast_ranks(rank_age))
        # Pre-fetch stats and sort by AVG descending
        group_stats = []
        for short, full_name, team in players:
            hp = h_totals.get((short, team)) if short else None
            pp = p_totals.get((short, team)) if short else None
            avg_v = (hp['h'] / hp['ab'])            if (hp and hp['ab'] > 0)        else None
            h_v   = hp['h']                         if hp else None
            hr_v  = hp['hr']                        if hp else None
            rbi_v = hp['rbi']                       if hp else None
            r_v   = hp['r']                         if hp else None
            sb_v  = hp['sb']                        if hp else None
            bb_v  = hp['bb']                        if hp else None
            ip_v  = pp['ip_dec']                    if (pp and pp['ip_dec'] >= 0.01) else None
            era_v = (pp['er'] * 9 / pp['ip_dec'])   if (pp and pp['ip_dec'] >= 0.01) else None
            str_v = (pp['strikes'] / pp['pitches']) if (pp and pp['pitches'] > 0)   else None
            group_stats.append((short, full_name, team, avg_v, h_v, hr_v, rbi_v, r_v, sb_v, bb_v, ip_v, era_v, str_v))

        group_stats.sort(key=lambda e: e[3] if e[3] is not None else -1.0, reverse=True)

        # Title row (merged across 10 cols)
        rows.append([roster_title] + [''] * (N_COLS - 1))
        reqs.append(merge_req(sid, cur_r, 0, cur_r + 1, N_COLS))
        reqs.append(range_fmt_req(sid, cur_r, 0, cur_r + 1, N_COLS,
            cell_fmt(bg='7B5E00', bold=True, color='FFFFFF', size=11)))
        cur_r += 1

        # Column headers
        rows.append(['Player', 'Team', 'AVG', 'Rk', 'H', 'Rk', 'HR', 'Rk', 'RBI', 'Rk', 'R', 'Rk', 'SB', 'Rk', 'BB', 'Rk', 'IP', 'Rk', 'ERA', 'Rk', 'Strike%', 'Rk'])
        reqs.append(range_fmt_req(sid, cur_r, 0, cur_r + 1, N_COLS,
            cell_fmt(bg='C9A227', bold=True, color='FFFFFF', size=9)))
        cur_r += 1

        # Data rows
        for display_i, (short, full_name, team, avg_v, h_v, hr_v, rbi_v, r_v, sb_v, bb_v, ip_v, era_v, str_v) in enumerate(group_stats):
            bg  = 'FFF8E1' if display_i % 2 == 0 else 'FFFFFF'
            key = (short, team) if short else None

            avg_str = f"{avg_v:.3f}"           if avg_v  is not None else '—'
            avg_rk  = rk['avg'].get(key, '—')  if key else '—'
            h_str   = str(h_v)                 if h_v    is not None else '—'
            h_rk    = rk['h'].get(key, '—')    if key else '—'
            hr_str  = str(hr_v)                if hr_v   is not None else '—'
            hr_rk   = rk['hr'].get(key, '—')   if key else '—'
            rbi_str = str(rbi_v)            if rbi_v  is not None else '—'
            rbi_rk  = rk['rbi'].get(key, '—') if key else '—'
            r_str   = str(r_v)              if r_v    is not None else '—'
            r_rk    = rk['r'].get(key, '—')   if key else '—'
            sb_str  = str(sb_v)             if sb_v   is not None else '—'
            sb_rk   = rk['sb'].get(key, '—')  if key else '—'
            bb_str  = str(bb_v)             if bb_v   is not None else '—'
            bb_rk   = rk['bb'].get(key, '—')  if key else '—'
            ip_str  = dec_to_ip(ip_v)       if ip_v   is not None else '—'
            ip_rk   = rk['ip'].get(key, '—')  if key else '—'
            era_str = f"{era_v:.2f}"        if era_v  is not None else '—'
            era_rk  = rk['era'].get(key, '—') if key else '—'
            str_str = f"{str_v:.1%}"        if str_v  is not None else '—'
            str_rk  = rk['str'].get(key, '—') if key else '—'

            rows.append([full_name, team,
                         avg_str, avg_rk, h_str,   h_rk,  hr_str,  hr_rk,
                         rbi_str, rbi_rk, r_str,   r_rk,  sb_str,  sb_rk,
                         bb_str,  bb_rk,  ip_str,  ip_rk, era_str, era_rk,
                         str_str, str_rk])
            reqs.append(range_fmt_req(sid, cur_r, 0, cur_r + 1, N_COLS,
                cell_fmt(bg=bg, size=9)))
            reqs.append(range_fmt_req(sid, cur_r, 0, cur_r + 1, 2,
                cell_fmt(bg=bg, size=9, halign='LEFT')))
            cur_r += 1

        # Two blank rows between tables
        rows.extend([[''] * N_COLS, [''] * N_COLS])
        cur_r += 2

    # Convert all values to strings to avoid mixed-type serialization issues
    str_rows = [[str(v) if v != '' else '' for v in row] for row in rows]

    # Unmerge all existing cells first (ws.clear() only clears values, not merges).
    # Stale merges from previous runs silently swallow cell writes for non-top-left cells.
    total_rows = len(str_rows)
    pre_reqs = [{
        'unmergeCells': {
            'range': {
                'sheetId': sid,
                'startRowIndex': 0, 'endRowIndex': max(total_rows + 5, 50),
                'startColumnIndex': 0, 'endColumnIndex': N_COLS,
            }
        }
    }]
    try:
        sh.batch_update({'requests': pre_reqs})
    except Exception:
        pass  # If no merges exist the API may return an error; safe to ignore

    ws.clear()
    ws.update(str_rows, 'A1', value_input_option='RAW')

    # Column widths (pixels): Player, Team, AVG, Rk, H, Rk, HR, Rk, RBI, Rk, R, Rk, SB, Rk, BB, Rk, IP, Rk, ERA, Rk, Strike%, Rk
    for i, w in enumerate([200, 90, 60, 38, 45, 38, 45, 38, 45, 38, 40, 38, 45, 38, 45, 38, 55, 38, 60, 38, 70, 38]):
        reqs.append(col_width_req(sid, i, w))

    reqs.append(tab_color_req(sid, 'B8860B'))
    sh.batch_update({'requests': reqs})


def push_standings_results(sh, ws):
    sid = ws.id
    import importlib.util as _ilu
    _res_spec = _ilu.spec_from_file_location("results", os.path.join(THIS_DIR, 'results.py'))
    _res_mod  = _ilu.module_from_spec(_res_spec)
    _res_spec.loader.exec_module(_res_mod)
    standings = _res_mod.get_standings()
    games     = _res_mod.GAMES

    reqs = []
    rows = []

    # ── Section A: Standings ──────────────────────────────────────────────────
    N_STAND = 14
    rows.append(["2026 Alameda Little League Majors — STANDINGS"] + [''] * (N_STAND - 1))
    reqs.append(merge_req(sid, 0, 0, 1, N_STAND))
    reqs.append(range_fmt_req(sid, 0, 0, 1, N_STAND,
        cell_fmt(bg='0D4B4B', bold=True, color='FFFFFF', size=16)))

    rows.append([STAMP] + [''] * (N_STAND - 1))
    reqs.append(merge_req(sid, 1, 0, 2, N_STAND))
    reqs.append(range_fmt_req(sid, 1, 0, 2, N_STAND,
        cell_fmt(bg='1A6B6B', italic=True, color='FFFFFF', size=9)))

    hdrs = ['Team','W','L','T','PCT','GB','RS','RA','+/-','Streak','Home','Away','Littlejohn','Wood']
    rows.append(hdrs)
    reqs.append(range_fmt_req(sid, 2, 0, 3, N_STAND,
        cell_fmt(bg='1A6B6B', bold=True, color='FFFFFF', size=10)))

    for i, rd in enumerate(standings):
        bg = 'E6F5F5' if i % 2 == 0 else 'FFFFFF'
        # Use a space-padded format for W-L records so Sheets doesn't parse them as dates
        # e.g. "5-0" → "5 - 0"
        def rec(s): return s.replace('-', ' - ') if isinstance(s, str) else s
        row = [rd['team'], rd['w'], rd['l'], rd['t'],
               rd['pct'], rd['gb'],
               rd['rs'], rd['ra'], rd['diff'], rd['streak'],
               rec(rd['home_rec']), rec(rd['away_rec']),
               rec(rd['lj_rec']),   rec(rd['wood_rec'])]
        rows.append(row)
        abs_r = 3 + i
        reqs.append(range_fmt_req(sid, abs_r, 0, abs_r+1, N_STAND, cell_fmt(bg=bg, size=10)))
        reqs.append(range_fmt_req(sid, abs_r, 0, abs_r+1, 1,       cell_fmt(bg=bg, size=10, halign='LEFT')))
        # Color +/- column green/red
        diff_color = '006400' if rd['diff'] > 0 else ('8B0000' if rd['diff'] < 0 else '000000')
        reqs.append(range_fmt_req(sid, abs_r, 8, abs_r+1, 9,
            cell_fmt(bg=bg, size=10, color=diff_color)))
        # Format PCT as 3 decimal places
        reqs.append(range_fmt_req(sid, abs_r, 4, abs_r+1, 5,
            cell_fmt(bg=bg, size=10, fmt_pattern='0.000')))

    # Two blank rows gap
    rows.extend([[''] * N_STAND, [''] * N_STAND])

    # ── Section B: Game Log ───────────────────────────────────────────────────
    log_start_r = len(rows)  # 0-indexed
    N_LOG = 8
    rows.append(["2026 GAME LOG — All Results"] + [''] * (N_LOG - 1))
    reqs.append(merge_req(sid, log_start_r, 0, log_start_r + 1, N_LOG))
    reqs.append(range_fmt_req(sid, log_start_r, 0, log_start_r + 1, N_LOG,
        cell_fmt(bg='7B1A1A', bold=True, color='FFFFFF', size=14)))

    log_hdr_r = log_start_r + 1
    rows.append(['Date', 'Away', 'Home', 'Away Score', 'Home Score', 'Winner', 'Field', 'Notes'])
    reqs.append(range_fmt_req(sid, log_hdr_r, 0, log_hdr_r + 1, N_LOG,
        cell_fmt(bg='A03030', bold=True, color='FFFFFF', size=10)))

    sorted_games = sorted(games, key=lambda x: x['date'])
    for i, g in enumerate(sorted_games):
        ha_known = g.get('away') is not None
        away  = g['away']       if ha_known else g['team_a']
        home  = g['home']       if ha_known else g['team_b']
        a_sc  = g['away_score'] if ha_known else g['score_a']
        h_sc  = g['home_score'] if ha_known else g['score_b']
        notes = "" if ha_known else "H/A unconfirmed"
        bg    = 'FFF0F0' if i % 2 == 0 else 'FFFFFF'
        abs_r = log_hdr_r + 1 + i
        rows.append([g['date'], away, home, a_sc, h_sc, g['winner'], g['field'], notes])
        reqs.append(range_fmt_req(sid, abs_r, 0, abs_r+1, N_LOG, cell_fmt(bg=bg, size=10)))
        reqs.append(range_fmt_req(sid, abs_r, 0, abs_r+1, 3,     cell_fmt(bg=bg, size=10, halign='LEFT')))
        reqs.append(range_fmt_req(sid, abs_r, 5, abs_r+1, 6,     cell_fmt(bg=bg, size=10, halign='LEFT')))
        if notes:
            reqs.append(range_fmt_req(sid, abs_r, 7, abs_r+1, 8,
                cell_fmt(bg=bg, size=9, italic=True, color='888888', halign='LEFT')))

    ws.clear()
    # RAW mode prevents Sheets from auto-converting "5 - 0" records into dates
    ws.update(rows, 'A1', value_input_option='RAW')

    # Column widths
    stand_widths = [120, 35, 35, 35, 55, 45, 45, 45, 55, 60, 75, 75, 85, 70]
    for i, w in enumerate(stand_widths): reqs.append(col_width_req(sid, i, w))

    reqs.append(freeze_req(sid, rows=3))
    reqs.append(tab_color_req(sid, '1A6B6B'))
    sh.batch_update({'requests': reqs})


# =============================================================================
# 9. MAIN
# =============================================================================
if __name__ == "__main__":
    print("Connecting to Google Sheets...")
    gc = connect()

    print("Opening/creating spreadsheet...")
    sh = get_or_create_spreadsheet(gc)

    print("Setting up worksheets...")
    tabs = setup_worksheets(sh)

    pushers = [
        ("🏆 Hitting Leaders",     push_hitting_leaders),
        ("⚾ Pitching Leaders",    push_pitching_leaders),
        ("📊 Team Hitting",        push_team_hitting),
        ("📊 Team Pitching",       push_team_pitching),
        ("🥎 Player Hitting",      push_player_hitting),
        ("🎯 Player Pitching",     push_player_pitching),
        ("⭐ All Star Tracker",    push_all_star_tracker),
        ("📋 Standings & Results", push_standings_results),
    ]

    for tab_title, pusher in pushers:
        print(f"  Writing {tab_title}...")
        pusher(sh, tabs[tab_title])
        time.sleep(1)   # stay comfortably under Sheets API rate limits

    print(f"\n✅  Done!")
    print(f"    Sheet: https://docs.google.com/spreadsheets/d/{sh.id}")
    print(f"    Share this link with your co-manager.")
