# roster.py — 2026 Alameda Little League Majors
# Source: Draft board. age = baseball age (as of 2026 season).
# short_name matches the display_name key used in game files (name field, no jersey).
# jersey = jersey number as seen in game files (None if not yet observed).
# allstar = 2025 all-star designation: "11u All-Star", "10u All-Star", "11u Future Stars", or None.
# Note: Jonah Kim was a 2025 10u All-Star but is not on a 2026 roster.

ROSTER = {
    "Marlins": [
        {"full": "Kaleo Pontmayor",    "short": "Kaleo P",    "jersey": 10,  "age": 12, "allstar": "11u All-Star"},
        {"full": "Nico Yuen",          "short": "Nico Y",     "jersey": 0,   "age": 12, "allstar": "11u All-Star"},
        {"full": "Julian Warner",      "short": "Julian W",   "jersey": 3,   "age": 12, "allstar": "11u Future Stars"},
        {"full": "Wilder Eula",        "short": "Wilder E",   "jersey": 17,  "age": 11, "allstar": "10u All-Star"},
        {"full": "Mayer Hemberg",      "short": "Mayer H",    "jersey": 5,   "age": 12, "allstar": "11u Future Stars"},
        {"full": "Jax Huang",          "short": "Jax H",      "jersey": 23,  "age": 11, "allstar": "10u All-Star"},
        {"full": "Francis Goray",      "short": "Frankie G",  "jersey": 28,  "age": 11, "allstar": None},
        {"full": "Cassius Ward",       "short": "Cassius...", "jersey": 24,  "age": 12, "allstar": None},
        {"full": "Henry Baty",         "short": "Henry B",    "jersey": 16,  "age": 11, "allstar": None},
        {"full": "Wyatt Musgrave",     "short": "Wyatt M",    "jersey": 11,  "age": 12, "allstar": None},
        {"full": "Shawn Medina",       "short": "Shawn M",    "jersey": 12,  "age": 12, "allstar": None},
        {"full": "Andreas Satterfield","short": "Andreas...", "jersey": 27,  "age": 12, "allstar": None},
    ],
    "Giants": [
        {"full": "Jonah Lee",          "short": "Jonah L",    "jersey": 24,  "age": 12, "allstar": "11u All-Star"},
        {"full": "Kai Lin",            "short": "Kai L",      "jersey": 11,  "age": 12, "allstar": "11u All-Star"},
        {"full": "Carver Dole",        "short": "Carver D",   "jersey": 6,   "age": 12, "allstar": "11u Future Stars"},
        {"full": "Cameron Le",         "short": "Cameron L",  "jersey": 34,  "age": 11, "allstar": "10u All-Star"},
        {"full": "Aiden Gilling",      "short": "Aiden G",    "jersey": 22,  "age": 11, "allstar": "10u All-Star"},
        {"full": "Jaxon Mooningham",   "short": "Jaxon M",    "jersey": 2,   "age": 11, "allstar": "10u All-Star"},
        {"full": "Boden Neveu",        "short": "Boden N",    "jersey": 41,  "age": 11, "allstar": None},
        {"full": "Thomas Blood",       "short": "Thomas B",   "jersey": 10,  "age": 11, "allstar": None},
        {"full": "Griffin Clemons",    "short": "Griffin C",  "jersey": 8,   "age": 12, "allstar": None},
        {"full": "Michael Hupalo",     "short": "Michael H",  "jersey": 7,   "age": 12, "allstar": None},
        {"full": "Ben Holstius",       "short": "Benjami...", "jersey": 12,  "age": 12, "allstar": None},  # full first name likely Benjamin
        {"full": "River Alvarez",      "short": "River A",    "jersey": None,"age": 12, "allstar": None},
    ],
    "Guardians": [
        {"full": "Andrew Bryant",      "short": "Drew B",     "jersey": 4,   "age": 12, "allstar": "11u All-Star"},
        {"full": "Lennon Danielsson",  "short": "Lennon D",   "jersey": 34,  "age": 12, "allstar": "11u Future Stars"},
        {"full": "Soren Krajewski",    "short": "Soren K",    "jersey": 21,  "age": 12, "allstar": "11u Future Stars"},
        {"full": "Connor Fogarty",     "short": "Conor F",    "jersey": 24,  "age": 11, "allstar": "10u All-Star"},
        {"full": "Liam Thane",         "short": "Liam T",     "jersey": 10,  "age": 11, "allstar": None},
        {"full": "Luke Thane",         "short": "Luke T",     "jersey": 29,  "age": 11, "allstar": None},
        {"full": "Logan Means",        "short": "Logan M",    "jersey": 22,  "age": 12, "allstar": None},
        {"full": "Locke Merrill",      "short": "Lockie M",   "jersey": 27,  "age": 12, "allstar": None},
        {"full": "Hunter Dooling",     "short": "Hunter D",   "jersey": 6,   "age": 12, "allstar": None},
        {"full": "Carter Horvath",     "short": "Carter H",   "jersey": 7,   "age": 12, "allstar": None},
        {"full": "Patrick Chisholm",   "short": "Patrick C",  "jersey": 13,  "age": 11, "allstar": None},
        {"full": "Zeke Mendes",        "short": "Zeke M",     "jersey": 39,  "age": 11, "allstar": None},
    ],
    "White Sox": [
        {"full": "Adrien Romero",      "short": "Adrien R",   "jersey": 6,   "age": 12, "allstar": "11u All-Star"},
        {"full": "Wallace Beaver",     "short": "Ace B",      "jersey": 44,  "age": 11, "allstar": "10u All-Star"},  # goes by "Ace"
        {"full": "Sam Engel",          "short": "Sam E",      "jersey": 11,  "age": 12, "allstar": "11u Future Stars"},
        {"full": "Brayden Ko",         "short": "Brayden K",  "jersey": 7,   "age": 12, "allstar": None},
        {"full": "Julius Norgren",     "short": "Julius N",   "jersey": 30,  "age": 12, "allstar": "11u Future Stars"},
        {"full": "Hudson Chin",        "short": "Hudson C",   "jersey": 22,  "age": 12, "allstar": None},
        {"full": "Beni Rodriguez",     "short": "Beni R",     "jersey": 5,   "age": 12, "allstar": None},
        {"full": "John Griswold",      "short": "Jack G",     "jersey": 27,  "age": 11, "allstar": None},  # goes by "Jack"
        {"full": "Jaiden Norgren",     "short": "Jaiden N",   "jersey": 3,   "age": 11, "allstar": None},
        {"full": "Edward Mack",        "short": "Edward M",   "jersey": 24,  "age": 11, "allstar": None},
        {"full": "Phillip Tang",       "short": "Philip T",   "jersey": 17,  "age": 11, "allstar": None},
        {"full": "Louis Villamil",     "short": "Lou V",      "jersey": 14,  "age": 12, "allstar": None},
    ],
    "Brewers": [
        {"full": "Huston Garvine",          "short": "Huston G",    "jersey": 20,  "age": 12, "allstar": "11u All-Star"},
        {"full": "Zac Cheng",               "short": "Zach C",      "jersey": 3,   "age": 12, "allstar": "11u Future Stars"},
        {"full": "Miles Moyer",             "short": "Miles M",     "jersey": 7,   "age": 12, "allstar": "11u Future Stars"},
        {"full": "King Nguyen",             "short": "King N",      "jersey": 13,  "age": 11, "allstar": "10u All-Star"},
        {"full": "Zeke Woo",                "short": "Zeke W",      "jersey": 17,  "age": 12, "allstar": None},
        {"full": "Oliver Rowe",             "short": "Oliver R",    "jersey": 41,  "age": 12, "allstar": None},
        {"full": "Luciano Arce",            "short": "Luciano A",   "jersey": 4,   "age": 11, "allstar": "10u All-Star"},
        {"full": "Sebastian Davies-Perez",  "short": "Sebasti...",  "jersey": 33,  "age": 12, "allstar": None},
        {"full": "Theo Davies-Perez",       "short": "Theo D",      "jersey": 24,  "age": 12, "allstar": None},
        {"full": "Reece Lau",               "short": "Reece L",     "jersey": 11,  "age": 11, "allstar": None},
        {"full": "Walter Cheung",           "short": "Walter C",    "jersey": 2,   "age": 11, "allstar": None},
        {"full": "Clayton Lew",             "short": "Clayton L",   "jersey": 8,   "age": 11, "allstar": None},
    ],
    "Yankees": [
        {"full": "Roland Hatley",      "short": "Roland M",   "jersey": 99,  "age": 12, "allstar": "11u All-Star"},
        {"full": "Hudson Patterson",   "short": "Hudson P",   "jersey": 2,   "age": 12, "allstar": "11u All-Star"},
        {"full": "Max Moffett",        "short": "Max M",      "jersey": 14,  "age": 11, "allstar": "10u All-Star"},
        {"full": "Ben McDaniels",      "short": "Benny M",    "jersey": None,"age": 12, "allstar": "11u Future Stars"},
        {"full": "Thomas Deibert",     "short": "Thomas D",   "jersey": None,"age": 12, "allstar": None},
        {"full": "Ben Buehmann",       "short": "Ben B",      "jersey": 26,  "age": 12, "allstar": None},
        {"full": "Severnio Alconcher", "short": "Severin...", "jersey": 15,  "age": 12, "allstar": None},
        {"full": "Brixton Lane",       "short": "Brixton L",  "jersey": None,"age": 12, "allstar": None},
        {"full": "Adam Hassen",        "short": "Adam H",     "jersey": 12,  "age": 11, "allstar": None},
        {"full": "Owen Seibert",       "short": "Owen S",     "jersey": None,"age": 11, "allstar": None},
        {"full": "Henry Seibert",      "short": "Henry S",    "jersey": 7,   "age": 11, "allstar": None},
        {"full": "Jet Slota-Loh",      "short": "Jet S",      "jersey": 17,  "age": 11, "allstar": None},
    ],
    "Padres": [
        {"full": "Orion Mitchell",     "short": "Orion M",    "jersey": 13,  "age": 12, "allstar": "11u All-Star"},
        {"full": "Robert Fagaly",      "short": "RJ F",       "jersey": 22,  "age": 12, "allstar": "11u All-Star"},  # goes by "RJ"
        {"full": "Miles Denman",       "short": "Miles D",    "jersey": 24,  "age": 12, "allstar": "11u Future Stars"},
        {"full": "Sam Gilmore",        "short": "Samuel G",   "jersey": 7,   "age": 12, "allstar": "11u Future Stars"},
        {"full": "Jonah Mackey",       "short": "Jonah M",    "jersey":  4,  "age": 12, "allstar": None},
        {"full": "Arthur Bainer",      "short": "Arthur B",   "jersey": None,"age": 11, "allstar": None},
        {"full": "Adrian Thomas",      "short": "Adrian T",   "jersey": None,"age": 11, "allstar": "10u All-Star"},
        {"full": "Ezekiel Cruz",       "short": "Ezekiel C",  "jersey": None,"age": 11, "allstar": None},
        {"full": "AJ Losk",            "short": "AJ L",       "jersey": None,"age": 12, "allstar": None},
        {"full": "Cruz Bargas",        "short": "Cruz B",     "jersey": None,"age": 12, "allstar": None},
        {"full": "Donovan Kim",        "short": "Donovan K",  "jersey": 51,  "age": 11, "allstar": None},
        {"full": "Brody Eastman",      "short": "Brody E",    "jersey": 44,  "age": 11, "allstar": None},
    ],
    "Astros": [
        {"full": "Jordan Cerda-Zein",  "short": "Jordan C",   "jersey": 3,   "age": 12, "allstar": "11u All-Star"},
        {"full": "Colton Dignon",      "short": "Colton D",   "jersey": 19,  "age": 12, "allstar": "11u All-Star"},
        {"full": "Connor Zuckerman",   "short": "Connor Z",   "jersey": 23,  "age": 11, "allstar": "10u All-Star"},
        {"full": "Carter Flores",      "short": "Carter F",   "jersey": 24,  "age": 12, "allstar": "11u Future Stars"},
        {"full": "Julian Paiso",       "short": "Julian P",   "jersey": 5,   "age": 11, "allstar": "10u All-Star"},
        {"full": "Lukas Imperial",     "short": "Lukas I",    "jersey": 11,  "age": 11, "allstar": None},
        {"full": "Kolin Imperial",     "short": "Kolin I",    "jersey": None,"age": 12, "allstar": None},
        {"full": "Logan Sherrat",      "short": "Logan S",    "jersey": 8,   "age": 11, "allstar": None},
        {"full": "Rio Shepard",        "short": "Rio S",      "jersey": 10,  "age": 12, "allstar": None},
        {"full": "Niall Felipe",       "short": "Niall F",    "jersey": None,"age": 11, "allstar": None},
        {"full": "Max Hauer",          "short": "Max H",      "jersey": None,"age": 12, "allstar": None},
        {"full": "Ben Wilichinsky",    "short": "Benjami...", "jersey": 26,  "age": 12, "allstar": None},
    ],
}

# Flat lookup: (short_name, team) -> player dict
# Useful for joining with h_totals / p_totals keys
def get_player(short_name, team):
    for p in ROSTER.get(team, []):
        if p["short"] == short_name:
            return p
    return None

# Age lookup by (short_name, team) — returns int age or None
def get_age(short_name, team):
    p = get_player(short_name, team)
    return p["age"] if p else None

# All-star lookup by (short_name, team) — returns designation string or None
def get_allstar(short_name, team):
    p = get_player(short_name, team)
    return p["allstar"] if p else None

# Summary counts
AGE_11   = [(p["full"], team) for team, players in ROSTER.items() for p in players if p["age"] == 11]
AGE_12   = [(p["full"], team) for team, players in ROSTER.items() for p in players if p["age"] == 12]
ALLSTARS = [(p["full"], team, p["allstar"]) for team, players in ROSTER.items() for p in players if p["allstar"]]
