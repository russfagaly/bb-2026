"""
analyze_11u.py
==============
Extracts stats for all age-11 players for the 2026 11u All-Star Manager Report.
Outputs a JSON file with all computed data for use by the docx generator.

Usage:
    python3 pipeline/analyze_11u.py > pipeline/11u_data.json
"""

import os, sys, re, importlib.util, json
from collections import defaultdict

THIS_DIR  = os.path.dirname(os.path.abspath(__file__))
STATS_DIR = os.path.dirname(THIS_DIR)
GAMES_DIR = os.path.join(STATS_DIR, "games")

sys.path.insert(0, THIS_DIR)
from roster import ROSTER

# =============================================================================
# 1. IDENTIFY AGE-11 PLAYERS
# =============================================================================
age11_set = set()  # (short_name, team)
age11_info = {}    # (short_name, team) -> full player dict

for team, players in ROSTER.items():
    for p in players:
        if p["age"] == 11:
            key = (p["short"], team)
            age11_set.add(key)
            age11_info[key] = p

# =============================================================================
# 2. LOAD ALL GAME FILES
# =============================================================================
all_hitting  = []
all_pitching = []
all_dates_by_team = defaultdict(list)  # team -> sorted list of dates played

game_files = sorted(f for f in os.listdir(GAMES_DIR) if f.endswith('.py'))

for fname in game_files:
    path = os.path.join(GAMES_DIR, fname)
    spec = importlib.util.spec_from_file_location("gf", path)
    mod  = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    team = mod.TEAM
    date = mod.DATE

    all_dates_by_team[team].append(date)

    for row in getattr(mod, 'hitting', []):
        all_hitting.append({**row, 'team': team, 'date': date})

    for row in getattr(mod, 'pitching', []):
        all_pitching.append({**row, 'team': team, 'date': date})

# Sort dates per team
for team in all_dates_by_team:
    all_dates_by_team[team] = sorted(set(all_dates_by_team[team]))

# =============================================================================
# 3. HELPER FUNCTIONS
# =============================================================================
def display_name(raw):
    return raw.split(' #')[0].strip()

def ip_to_dec(ip_str):
    s = str(ip_str)
    if '.' not in s:
        return float(s)
    whole, frac = s.split('.')
    return int(whole) + int(frac) / 3.0

def dec_to_ip_str(dec):
    total_thirds = round(dec * 3)
    whole  = total_thirds // 3
    thirds = total_thirds % 3
    return f"{whole}.{thirds}"

def safe_div(n, d, default=0.0):
    return n / d if d else default

def fmt_avg(v):
    return f".{round(v*1000):03d}"

def fmt_era(v):
    return f"{v:.2f}" if v < 99 else "—"

def fmt_whip(v):
    return f"{v:.2f}" if v < 99 else "—"

# =============================================================================
# 4. AGGREGATE SEASON TOTALS for age-11 players
# =============================================================================
h_totals = defaultdict(lambda: {
    'team': '', 'games': 0,
    'ab': 0, 'r': 0, 'h': 0, 'rbi': 0, 'bb': 0, 'so': 0,
    'sb': 0, 'cs': 0, 'e': 0, 'doubles': 0, 'triples': 0, 'hr': 0, 'hbp': 0
})

p_totals = defaultdict(lambda: {
    'team': '', 'games': 0,
    'ip_dec': 0.0, 'h': 0, 'r': 0, 'er': 0,
    'bb': 0, 'so': 0, 'pitches': 0, 'strikes': 0, 'bf': 0, 'hbp': 0,
    'appearances': []  # list of (date, ip_dec, pitches) for workload/recency
})

# Track game-by-game lines for last-4-game splits
h_game_lines = defaultdict(list)  # (name, team) -> list of {date, stats...}
p_game_lines = defaultdict(list)  # (name, team) -> list of {date, stats...}

for row in all_hitting:
    dname = display_name(row['name'])
    team  = row['team']
    key   = (dname, team)

    # Check if this player is age-11 (match short name)
    matched_key = None
    for (short, t) in age11_set:
        if t == team and short == dname:
            matched_key = (short, t)
            break

    if matched_key is None:
        continue

    p = h_totals[key]
    p['team'] = team
    p['games'] += 1
    for stat in ('ab','r','h','rbi','bb','so','sb','cs','e','doubles','triples','hr','hbp'):
        p[stat] += row.get(stat, 0)

    h_game_lines[key].append({
        'date': row['date'],
        'ab': row.get('ab',0), 'r': row.get('r',0), 'h': row.get('h',0),
        'rbi': row.get('rbi',0), 'bb': row.get('bb',0), 'so': row.get('so',0),
        'doubles': row.get('doubles',0), 'triples': row.get('triples',0),
        'hr': row.get('hr',0), 'sb': row.get('sb',0), 'cs': row.get('cs',0),
        'hbp': row.get('hbp',0), 'e': row.get('e',0),
    })

for row in all_pitching:
    dname = display_name(row['name'])
    team  = row['team']
    key   = (dname, team)

    matched_key = None
    for (short, t) in age11_set:
        if t == team and short == dname:
            matched_key = (short, t)
            break

    if matched_key is None:
        continue

    ip_d = ip_to_dec(row['ip'])
    p = p_totals[key]
    p['team'] = team
    p['games'] += 1
    p['ip_dec'] += ip_d
    for stat in ('h','r','er','bb','so','hbp'):
        p[stat] += row.get(stat, 0)
    p['pitches'] += row.get('pitches', 0)
    p['strikes'] += row.get('strikes', 0)
    bf = row.get('bf', 0)
    if bf > 0:
        p['bf'] += bf
    p['appearances'].append({
        'date': row['date'],
        'ip_dec': ip_d,
        'pitches': row.get('pitches', 0),
    })

    p_game_lines[key].append({
        'date': row['date'],
        'ip_dec': ip_d,
        'ip_str': dec_to_ip_str(ip_d),
        'h': row.get('h',0), 'r': row.get('r',0), 'er': row.get('er',0),
        'bb': row.get('bb',0), 'so': row.get('so',0),
        'pitches': row.get('pitches',0), 'strikes': row.get('strikes',0),
        'bf': row.get('bf',0),
    })

# Sort game lines by date
for key in h_game_lines:
    h_game_lines[key].sort(key=lambda x: x['date'])
for key in p_game_lines:
    p_game_lines[key].sort(key=lambda x: x['date'])

# =============================================================================
# 5. COMPUTE RATE STATS
# =============================================================================
def compute_hit_rates(p):
    ab  = p['ab']
    bb  = p['bb']
    hbp = p['hbp']
    h   = p['h']
    d   = p['doubles']
    t   = p['triples']
    hr  = p['hr']
    so  = p['so']
    sb  = p['sb']
    cs  = p['cs']

    avg  = safe_div(h, ab)
    obp  = safe_div(h+bb+hbp, ab+bb+hbp)
    tb   = h + d + 2*t + 3*hr
    slg  = safe_div(tb, ab)
    ops  = obp + slg
    xbh  = d + t + hr
    pa   = ab + bb + hbp
    bb_pct = safe_div(bb, pa) * 100
    k_pct  = safe_div(so, pa) * 100
    sb_pct = safe_div(sb, sb+cs) * 100 if (sb+cs) > 0 else None

    return {
        'avg': avg, 'obp': obp, 'slg': slg, 'ops': ops,
        'tb': tb, 'xbh': xbh, 'pa': pa,
        'bb_pct': bb_pct, 'k_pct': k_pct, 'sb_pct': sb_pct,
        'avg_str': fmt_avg(avg),
        'obp_str': fmt_avg(obp),
        'slg_str': fmt_avg(slg),
        'ops_str': f"{ops:.3f}".lstrip('0') if ops < 1 else f"{ops:.3f}",
    }

def compute_pit_rates(p):
    ip = p['ip_dec']
    if ip < 0.01:
        return None
    era   = safe_div(p['er']*9, ip, 99.0)
    whip  = safe_div(p['h']+p['bb'], ip, 99.0)
    k9    = safe_div(p['so']*9, ip)
    bb9   = safe_div(p['bb']*9, ip)
    h9    = safe_div(p['h']*9, ip)
    str_pct = safe_div(p['strikes'], p['pitches']) * 100 if p['pitches'] > 0 else 0
    k_bb  = safe_div(p['so'], p['bb'])
    bf    = p['bf']
    k_pct = safe_div(p['so'], bf) * 100 if bf > 0 else None
    bb_pct = safe_div(p['bb'], bf) * 100 if bf > 0 else None

    return {
        'ip_str': dec_to_ip_str(ip),
        'era': era, 'whip': whip,
        'k9': k9, 'bb9': bb9, 'h9': h9,
        'strike_pct': str_pct,
        'k_bb': k_bb,
        'k_pct': k_pct,
        'bb_pct': bb_pct,
        'era_str': fmt_era(era),
        'whip_str': fmt_whip(whip),
    }

# =============================================================================
# 6. LAST-4-GAME SPLITS
# =============================================================================
def last4_hit(key):
    lines = h_game_lines.get(key, [])
    recent = lines[-4:]  # last up to 4 games
    if not recent:
        return None
    totals = {s: sum(g[s] for g in recent)
              for s in ('ab','r','h','rbi','bb','so','doubles','triples','hr','sb','cs','hbp','e')}
    totals['games'] = len(recent)
    totals['dates'] = [g['date'] for g in recent]
    rates = compute_hit_rates(totals)
    return {**totals, **rates}

def last4_pit(key):
    lines = p_game_lines.get(key, [])
    recent = lines[-4:]
    if not recent:
        return None
    ip_dec = sum(g['ip_dec'] for g in recent)
    totals = {
        'ip_dec': ip_dec,
        'ip_str': dec_to_ip_str(ip_dec),
        'h': sum(g['h'] for g in recent),
        'r': sum(g['r'] for g in recent),
        'er': sum(g['er'] for g in recent),
        'bb': sum(g['bb'] for g in recent),
        'so': sum(g['so'] for g in recent),
        'pitches': sum(g['pitches'] for g in recent),
        'strikes': sum(g.get('strikes', 0) for g in recent),
        'bf': sum(g['bf'] for g in recent),
        'games': len(recent),
        'dates': [g['date'] for g in recent],
    }
    rates = compute_pit_rates(totals) or {}
    return {**totals, **rates}

# =============================================================================
# 7. BUILD OUTPUT RECORDS
# =============================================================================
players_out = []

for (short, team), info in sorted(age11_info.items(), key=lambda x: (x[0][1], x[0][0])):
    full_name = info['full']
    allstar   = info['allstar']
    jersey    = info['jersey']

    # Hitting
    h_key = (short, team)
    h_tot = h_totals.get(h_key)
    h_rates = compute_hit_rates(h_tot) if h_tot and h_tot['ab'] > 0 else None
    h_last4 = last4_hit(h_key)

    # Pitching
    p_key = (short, team)
    p_tot = p_totals.get(p_key)
    p_rates = compute_pit_rates(p_tot) if p_tot else None
    p_last4 = last4_pit(p_key)

    # Two-way?
    has_hit  = h_tot is not None and h_tot['games'] > 0
    has_pit  = p_tot is not None and p_tot['games'] > 0
    two_way  = has_hit and has_pit

    # Most recent pitching appearance
    last_pitch_date = None
    if p_tot and p_tot['appearances']:
        sorted_apps = sorted(p_tot['appearances'], key=lambda x: x['date'])
        last_pitch_date = sorted_apps[-1]['date']

    record = {
        'short': short,
        'full': full_name,
        'team': team,
        'jersey': jersey,
        'allstar': allstar,
        'two_way': two_way,
        'hitting': {
            **(h_tot if h_tot else {}),
            'rates': h_rates,
            'last4': h_last4,
        } if has_hit else None,
        'pitching': {
            **{k: v for k, v in (p_tot or {}).items() if k != 'appearances'},
            'ip_str': dec_to_ip_str(p_tot['ip_dec']) if p_tot else None,
            'rates': p_rates,
            'last4': p_last4,
            'appearances': p_tot['appearances'] if p_tot else [],
            'last_pitch_date': last_pitch_date,
        } if has_pit else None,
    }
    players_out.append(record)

# =============================================================================
# 8. SUMMARY STATS (for report context)
# =============================================================================
# All hitters with >= 5 AB
hitters_ranked = sorted(
    [p for p in players_out if p['hitting'] and p['hitting'].get('ab',0) >= 5],
    key=lambda x: x['hitting']['rates']['avg'] if x['hitting']['rates'] else 0,
    reverse=True
)

# All pitchers with >= 1.0 IP
pitchers_ranked = sorted(
    [p for p in players_out if p['pitching'] and p['pitching'].get('ip_dec',0) >= 1.0],
    key=lambda x: x['pitching']['rates']['era'] if x['pitching']['rates'] else 99,
)

# allstars subset
allstar_players = [p for p in players_out if p['allstar'] in ('10u All-Star', '10u All-Stars')]

# =============================================================================
# 9. OUTPUT JSON
# =============================================================================
output = {
    'players': players_out,
    'hitters_ranked_by_avg': [p['short']+'|'+p['team'] for p in hitters_ranked],
    'pitchers_ranked_by_era': [p['short']+'|'+p['team'] for p in pitchers_ranked],
    'total_age11': len(players_out),
    'total_allstars': len(allstar_players),
}

print(json.dumps(output, indent=2, default=str))
