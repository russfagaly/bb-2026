# results.py — 2026 Alameda Little League Majors
# Complete game results log.
# Fields: date, away, home, away_score, home_score, winner, field
# All games have confirmed home/away designations.
# field: "Littlejohn" = weekend games, "Wood" = weekday games.

GAMES = [
    # ── 03/07  Littlejohn ──────────────────────────────────────────────────
    {"date": "2026-03-07", "away": "White Sox",  "home": "Astros",     "away_score":  2, "home_score":  4, "winner": "Astros",     "field": "Littlejohn"},
    {"date": "2026-03-07", "away": "Brewers",    "home": "Marlins",    "away_score": 10, "home_score":  6, "winner": "Brewers",    "field": "Littlejohn"},

    # ── 03/08  Littlejohn ──────────────────────────────────────────────────
    {"date": "2026-03-08", "away": "Giants",     "home": "Yankees",    "away_score":  5, "home_score":  3, "winner": "Giants",     "field": "Littlejohn"},
    {"date": "2026-03-08", "away": "Guardians",  "home": "Padres",     "away_score":  4, "home_score":  2, "winner": "Guardians",  "field": "Littlejohn"},

    # ── 03/09  Wood ────────────────────────────────────────────────────────
    {"date": "2026-03-09", "away": "White Sox",  "home": "Brewers",    "away_score":  6, "home_score":  2, "winner": "White Sox",  "field": "Wood"},

    # ── 03/10  Wood ────────────────────────────────────────────────────────
    {"date": "2026-03-10", "away": "Astros",     "home": "Giants",     "away_score": 11, "home_score": 10, "winner": "Astros",     "field": "Wood"},

    # ── 03/11  Wood ────────────────────────────────────────────────────────
    {"date": "2026-03-11", "away": "Padres",     "home": "Yankees",    "away_score": 13, "home_score":  5, "winner": "Padres",     "field": "Wood"},

    # ── 03/12  Wood ────────────────────────────────────────────────────────
    {"date": "2026-03-12", "away": "Guardians",  "home": "Marlins",    "away_score":  8, "home_score": 12, "winner": "Marlins",    "field": "Wood"},

    # ── 03/14  Littlejohn ──────────────────────────────────────────────────
    {"date": "2026-03-14", "away": "Astros",     "home": "Guardians",  "away_score":  1, "home_score":  0, "winner": "Astros",     "field": "Littlejohn"},
    {"date": "2026-03-14", "away": "Padres",     "home": "Marlins",    "away_score": 11, "home_score":  7, "winner": "Padres",     "field": "Littlejohn"},
    {"date": "2026-03-14", "away": "Brewers",    "home": "Giants",     "away_score": 21, "home_score":  2, "winner": "Brewers",    "field": "Littlejohn"},
    {"date": "2026-03-14", "away": "Yankees",    "home": "White Sox",  "away_score":  1, "home_score":  2, "winner": "White Sox",  "field": "Littlejohn"},

    # ── 03/16  Wood ────────────────────────────────────────────────────────
    {"date": "2026-03-16", "away": "Brewers",    "home": "Astros",     "away_score":  3, "home_score": 11, "winner": "Astros",     "field": "Wood"},

    # ── 03/17  Wood ────────────────────────────────────────────────────────
    {"date": "2026-03-17", "away": "Yankees",    "home": "Guardians",  "away_score":  8, "home_score": 12, "winner": "Guardians",  "field": "Wood"},

    # ── 03/18  Wood ────────────────────────────────────────────────────────
    {"date": "2026-03-18", "away": "Giants",     "home": "Marlins",    "away_score":  5, "home_score": 15, "winner": "Marlins",    "field": "Wood"},

    # ── 03/19  Wood ────────────────────────────────────────────────────────
    {"date": "2026-03-19", "away": "White Sox",  "home": "Padres",     "away_score":  5, "home_score":  9, "winner": "Padres",     "field": "Wood"},

    # ── 03/21  Littlejohn ──────────────────────────────────────────────────
    {"date": "2026-03-21", "away": "Brewers",    "home": "Guardians",  "away_score":  7, "home_score":  1, "winner": "Brewers",    "field": "Littlejohn"},
    {"date": "2026-03-21", "away": "Yankees",    "home": "Marlins",    "away_score":  7, "home_score":  5, "winner": "Yankees",    "field": "Littlejohn"},
    {"date": "2026-03-21", "away": "Padres",     "home": "Astros",     "away_score":  7, "home_score":  4, "winner": "Padres",     "field": "Littlejohn"},
    {"date": "2026-03-21", "away": "White Sox",  "home": "Giants",     "away_score":  7, "home_score":  1, "winner": "White Sox",  "field": "Littlejohn"},

    # ── 03/23  Wood ────────────────────────────────────────────────────────
    {"date": "2026-03-23", "away": "Brewers",    "home": "Yankees",    "away_score":  2, "home_score":  8, "winner": "Yankees",    "field": "Wood"},

    # ── 03/24  Wood ────────────────────────────────────────────────────────
    {"date": "2026-03-24", "away": "White Sox",  "home": "Guardians",  "away_score":  7, "home_score":  6, "winner": "White Sox",  "field": "Wood"},

    # ── 03/25  Wood ────────────────────────────────────────────────────────
    {"date": "2026-03-25", "away": "Giants",     "home": "Padres",     "away_score":  7, "home_score": 14, "winner": "Padres",     "field": "Wood"},

    # ── 03/26  Wood ────────────────────────────────────────────────────────
    {"date": "2026-03-26", "away": "Marlins",    "home": "Astros",     "away_score": 12, "home_score":  7, "winner": "Marlins",    "field": "Wood"},

    # ── 03/28  Littlejohn ──────────────────────────────────────────────────
    {"date": "2026-03-28", "away": "Brewers",    "home": "Padres",     "away_score": 14, "home_score":  0, "winner": "Brewers",    "field": "Littlejohn"},
    {"date": "2026-03-28", "away": "Giants",     "home": "Guardians",  "away_score": 10, "home_score":  3, "winner": "Giants",     "field": "Littlejohn"},
    {"date": "2026-03-28", "away": "Marlins",    "home": "White Sox",  "away_score":  6, "home_score":  4, "winner": "Marlins",    "field": "Littlejohn"},
    {"date": "2026-03-28", "away": "Yankees",    "home": "Astros",     "away_score":  9, "home_score": 10, "winner": "Astros",     "field": "Littlejohn"},

    # ── 03/30  Wood ────────────────────────────────────────────────────────
    {"date": "2026-03-30", "away": "Padres",     "home": "Guardians",  "away_score":  8, "home_score":  4, "winner": "Padres",     "field": "Wood"},

    # ── 04/01  Wood ────────────────────────────────────────────────────────
    {"date": "2026-04-01", "away": "Astros",     "home": "White Sox",  "away_score":  9, "home_score":  5, "winner": "Astros",     "field": "Wood"},

    # ── 04/02  Wood ────────────────────────────────────────────────────────
    {"date": "2026-04-02", "away": "Marlins",    "home": "Brewers",    "away_score":  9, "home_score":  2, "winner": "Marlins",    "field": "Wood"},

    # ── 04/04  Littlejohn ──────────────────────────────────────────────────
    {"date": "2026-04-04", "away": "Astros",     "home": "Guardians",  "away_score":  1, "home_score":  2, "winner": "Guardians",  "field": "Littlejohn"},
    {"date": "2026-04-04", "away": "Padres",     "home": "Marlins",    "away_score":  3, "home_score":  5, "winner": "Marlins",    "field": "Littlejohn"},
    {"date": "2026-04-04", "away": "Brewers",    "home": "Giants",     "away_score": 22, "home_score":  2, "winner": "Brewers",    "field": "Littlejohn"},
    {"date": "2026-04-04", "away": "Yankees",    "home": "White Sox",  "away_score":  7, "home_score":  3, "winner": "Yankees",    "field": "Littlejohn"},

    # ── 04/06  Wood ────────────────────────────────────────────────────────
    {"date": "2026-04-06", "away": "White Sox",  "home": "Padres",     "away_score":  7, "home_score":  8, "winner": "Padres",     "field": "Wood"},

    # ── 04/07  Wood ────────────────────────────────────────────────────────
    {"date": "2026-04-07", "away": "Brewers",    "home": "Astros",     "away_score": 25, "home_score":  4, "winner": "Brewers",    "field": "Wood"},

    # ── 04/08  Wood ────────────────────────────────────────────────────────
    {"date": "2026-04-08", "away": "Yankees",    "home": "Guardians",  "away_score":  8, "home_score": 12, "winner": "Guardians",  "field": "Wood"},

    # ── 04/09  Wood ────────────────────────────────────────────────────────
    {"date": "2026-04-09", "away": "Giants",     "home": "Marlins",    "away_score": 10, "home_score": 11, "winner": "Marlins",    "field": "Wood"},

    # ── 04/18  Littlejohn ──────────────────────────────────────────────────
    {"date": "2026-04-18", "away": "Marlins",   "home": "Guardians",  "away_score":  0, "home_score":  6, "winner": "Guardians",  "field": "Littlejohn"},

    # ── 04/19  Littlejohn ──────────────────────────────────────────────────
    {"date": "2026-04-19", "away": "Brewers",   "home": "White Sox",  "away_score":  5, "home_score":  2, "winner": "Brewers",    "field": "Littlejohn"},

    # ── 04/23  Wood ────────────────────────────────────────────────────────
    {"date": "2026-04-23", "away": "Guardians", "home": "Giants",     "away_score":  4, "home_score": 10, "winner": "Giants",     "field": "Wood"},

    # ── 04/25  Littlejohn ──────────────────────────────────────────────────
    {"date": "2026-04-25", "away": "Guardians", "home": "Brewers",    "away_score":  2, "home_score":  3, "winner": "Brewers",    "field": "Littlejohn"},
    {"date": "2026-04-25", "away": "Marlins",   "home": "Yankees",    "away_score": 22, "home_score": 10, "winner": "Marlins",    "field": "Littlejohn"},
    {"date": "2026-04-25", "away": "Astros",    "home": "Padres",     "away_score": 10, "home_score":  5, "winner": "Astros",     "field": "Littlejohn"},
    {"date": "2026-04-25", "away": "Giants",    "home": "White Sox",  "away_score":  3, "home_score":  8, "winner": "White Sox",  "field": "Littlejohn"},

    # ── 04/26  Littlejohn ──────────────────────────────────────────────────
    {"date": "2026-04-26", "away": "Giants",    "home": "Astros",     "away_score":  1, "home_score":  3, "winner": "Astros",     "field": "Littlejohn"},
    {"date": "2026-04-26", "away": "Yankees",   "home": "Padres",     "away_score":  2, "home_score": 23, "winner": "Padres",     "field": "Littlejohn"},

    # ── 04/27  Wood ────────────────────────────────────────────────────────
    {"date": "2026-04-27", "away": "White Sox", "home": "Yankees",    "away_score": 13, "home_score":  5, "winner": "White Sox",  "field": "Wood"},

    # ── 04/28  Wood ────────────────────────────────────────────────────────
    {"date": "2026-04-28", "away": "Marlins",   "home": "Padres",     "away_score": 17, "home_score": 12, "winner": "Marlins",    "field": "Wood"},
]

# ── Helper lookups ──────────────────────────────────────────────────────────

def get_team_games(team):
    """Return all games involving a team, with that team's score and opponent score."""
    out = []
    for g in GAMES:
        if g["away"] == team:
            out.append({**g, "team": team, "team_score": g["away_score"], "opp_score": g["home_score"], "result": "W" if g["winner"] == team else "L"})
        elif g["home"] == team:
            out.append({**g, "team": team, "team_score": g["home_score"], "opp_score": g["away_score"], "result": "W" if g["winner"] == team else "L"})
        elif g.get("team_a") == team:
            out.append({**g, "team": team, "team_score": g["score_a"], "opp_score": g["score_b"], "result": "W" if g["winner"] == team else "L"})
        elif g.get("team_b") == team:
            out.append({**g, "team": team, "team_score": g["score_b"], "opp_score": g["score_a"], "result": "W" if g["winner"] == team else "L"})
    return out

def get_record(team):
    """Return (W, L, T) record for a team."""
    games = get_team_games(team)
    w = sum(1 for g in games if g["result"] == "W")
    l = sum(1 for g in games if g["result"] == "L")
    t = sum(1 for g in games if g["result"] == "T")
    return w, l, t

def get_streak(team):
    """Return current streak string, e.g. 'W3' or 'L2'."""
    games = sorted(get_team_games(team), key=lambda g: g["date"])
    if not games:
        return "-"
    streak_type = games[-1]["result"]
    count = 0
    for g in reversed(games):
        if g["result"] == streak_type:
            count += 1
        else:
            break
    return f"{streak_type}{count}"

def get_standings():
    """Return full standings for all teams, sorted by win pct then fewest losses."""
    rows = []
    for team in TEAMS:
        games = sorted(get_team_games(team), key=lambda g: g["date"])

        w = l = t = rs = ra = 0
        hw = hl = ht = 0   # home
        aw = al = at_ = 0  # away
        ljw = ljl = ljt = 0  # Littlejohn
        wdw = wdl = wdt = 0  # Wood

        for g in games:
            result  = g["result"]
            ts      = g["team_score"]
            os_     = g["opp_score"]
            field   = g["field"]
            is_home = g.get("home") == team
            is_away = g.get("away") == team
            ha_known = g.get("away") is not None

            # Overall
            if result == "W":   w  += 1
            elif result == "L": l  += 1
            else:               t  += 1
            rs += ts
            ra += os_

            # Home / Away (only when known)
            if ha_known:
                if is_home:
                    if result == "W":   hw += 1
                    elif result == "L": hl += 1
                    else:               ht += 1
                elif is_away:
                    if result == "W":   aw += 1
                    elif result == "L": al += 1
                    else:               at_ += 1

            # Field splits
            if field == "Littlejohn":
                if result == "W":   ljw += 1
                elif result == "L": ljl += 1
                else:               ljt += 1
            else:
                if result == "W":   wdw += 1
                elif result == "L": wdl += 1
                else:               wdt += 1

        gp   = w + l + t
        pct  = (w + 0.5 * t) / gp if gp > 0 else 0
        diff = rs - ra
        streak = get_streak(team)

        def rec(wins, losses, ties):
            if ties:
                return f"{wins}-{losses}-{ties}"
            return f"{wins}-{losses}"

        rows.append({
            "team":    team,
            "w": w, "l": l, "t": t,
            "gp":      gp,
            "pct":     pct,
            "rs":      rs,
            "ra":      ra,
            "diff":    diff,
            "streak":  streak,
            "home_rec":  rec(hw, hl, ht),
            "away_rec":  rec(aw, al, at_),
            "lj_rec":    rec(ljw, ljl, ljt),
            "wood_rec":  rec(wdw, wdl, wdt),
        })

    # Sort by win pct desc, then fewest losses
    rows.sort(key=lambda r: (-r["pct"], r["l"]))

    # Compute games behind leader
    leader_w = rows[0]["w"]
    leader_l = rows[0]["l"]
    for r in rows:
        gb = ((leader_w - r["w"]) + (r["l"] - leader_l)) / 2
        r["gb"] = "-" if gb == 0 else (f"{gb:.1f}" if gb % 1 else str(int(gb)))

    return rows


TEAMS = ["Astros", "Brewers", "Giants", "Guardians", "Marlins", "Padres", "White Sox", "Yankees"]

if __name__ == "__main__":
    rows = get_standings()
    print(f"{'Team':<12} {'W':>2} {'L':>2} {'T':>2}  {'PCT':>5}  {'GB':>4}  {'RS':>4} {'RA':>4} {'+/-':>5}  {'STK':>4}  {'HOME':>6}  {'AWAY':>6}  {'LJ':>6}  {'WOOD':>6}")
    print("-" * 100)
    for r in rows:
        print(
            f"{r['team']:<12} {r['w']:>2} {r['l']:>2} {r['t']:>2}  "
            f"{r['pct']:>5.3f}  {r['gb']:>4}  "
            f"{r['rs']:>4} {r['ra']:>4} {r['diff']:>+5}  "
            f"{r['streak']:>4}  "
            f"{r['home_rec']:>6}  {r['away_rec']:>6}  "
            f"{r['lj_rec']:>6}  {r['wood_rec']:>6}"
        )
